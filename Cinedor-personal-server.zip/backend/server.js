/**
 * Cinedor — Personal Video Server
 * --------------------------------------------------------------
 * Serves ONLY your own videos from the ./media folder.
 * No proxy, no outside links: the server never fetches anything
 * from other websites.
 *
 * Folder layout (one folder per video):
 *   media/
 *     My Trip 2026/
 *       info.json        (optional) {"title":"My Trip","year":"2026","description":"..."}
 *       poster.jpg       (optional)
 *       360p.mp4  720p.mp4  1080p.mp4      <- any name containing 360p/480p/720p/1080p
 *       hls/master.m3u8                    <- optional HLS (made with ffmpeg)
 *
 * Endpoints
 *   GET /api/health
 *   GET /api/videos            -> list
 *   GET /api/videos/:id        -> detail + qualities
 *   GET /media/...             -> the files (Range support -> seeking works)
 *
 * Optional lock: set APP_TOKEN=yourSecret  -> app must send header X-App-Token
 *
 * Node 18+   |   npm i   |   npm start
 */
'use strict';
const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

const PORT = Number(process.env.PORT) || 3000;
const PUBLIC_BASE_URL = (process.env.PUBLIC_BASE_URL || `http://localhost:${PORT}`).replace(/\/+$/, '');
const APP_TOKEN = process.env.APP_TOKEN || '';
const MEDIA_DIR = path.resolve(__dirname, 'media');

const VIDEO_EXT = /\.(mp4|m4v|webm|mkv)$/i;
const HLS_EXT = /\.(m3u8|m3u)$/i;
const IMG_EXT = /\.(jpe?g|png|webp)$/i;
const RANK = { '240p': 1, '360p': 2, '480p': 3, '720p': 4, '1080p': 5, '1440p': 6, '2160p': 7, Original: 8, 'Auto (HLS)': 9 };

const app = express();
app.use(cors());
app.disable('x-powered-by');

/* ---------------- optional token lock ---------------- */
function auth(req, res, next) {
  if (!APP_TOKEN) return next();
  const tok = req.get('X-App-Token') || req.query.token;
  if (tok === APP_TOKEN) return next();
  res.status(401).json({ success: false, error: 'Unauthorized' });
}

/* ---------------- helpers ---------------- */
const fileUrl = rel => `${PUBLIC_BASE_URL}/media/${rel.split(path.sep).map(encodeURIComponent).join('/')}`;
const slug = name => name.normalize('NFKD').replace(/[^\p{L}\p{N}]+/gu, '-').replace(/^-+|-+$/g, '').toLowerCase() || 'video';

function walk(dir, depth = 0, out = []) {
  if (depth > 3) return out;
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    if (e.name.startsWith('.')) continue;
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p, depth + 1, out); else out.push(p);
  }
  return out;
}

function qualityFromName(name) {
  const m = name.match(/(2160|1440|1080|720|480|360|240)p?/i);
  return m ? `${m[1]}p` : 'Original';
}

function readInfo(folder) {
  try { return JSON.parse(fs.readFileSync(path.join(folder, 'info.json'), 'utf8')); } catch { return {}; }
}

/* Scan media/ -> list of videos. Cached for 30 s so new files appear quickly. */
let scanCache = { at: 0, items: [] };
function scan() {
  if (Date.now() - scanCache.at < 30000) return scanCache.items;
  const items = [];
  if (!fs.existsSync(MEDIA_DIR)) fs.mkdirSync(MEDIA_DIR, { recursive: true });
  const used = new Set();
  for (const e of fs.readdirSync(MEDIA_DIR, { withFileTypes: true })) {
    if (!e.isDirectory() || e.name.startsWith('.')) continue;
    const folder = path.join(MEDIA_DIR, e.name);
    const files = walk(folder);
    const videos = files.filter(f => VIDEO_EXT.test(f));
    const hls = files.filter(f => HLS_EXT.test(f)).sort((a, b) => (/master/i.test(b) - /master/i.test(a)) || a.length - b.length)[0];
    if (!videos.length && !hls) continue;
    const info = readInfo(folder);
    const poster = files.find(f => IMG_EXT.test(f) && /poster|cover|thumb/i.test(path.basename(f))) || files.find(f => IMG_EXT.test(f));
    let id = slug(e.name), n = 2;
    while (used.has(id)) id = `${slug(e.name)}-${n++}`;
    used.add(id);
    const rel = f => path.relative(MEDIA_DIR, f);
    const qualities = videos.map(f => {
      const st = fs.statSync(f);
      return { quality: qualityFromName(path.basename(f)), url: fileUrl(rel(f)), type: 'mp4', size: st.size, downloadable: true };
    });
    if (hls) qualities.push({ quality: 'Auto (HLS)', url: fileUrl(rel(hls)), type: 'hls', size: null, downloadable: false });
    qualities.sort((a, b) => (RANK[a.quality] || 50) - (RANK[b.quality] || 50));
    items.push({
      id,
      title: info.title || e.name,
      year: info.year ? String(info.year) : null,
      description: info.description || '',
      poster: poster ? fileUrl(rel(poster)) : null,
      qualities,
      addedAt: fs.statSync(folder).mtimeMs
    });
  }
  items.sort((a, b) => b.addedAt - a.addedAt);
  scanCache = { at: Date.now(), items };
  return items;
}

/* ---------------- routes ---------------- */
app.get('/api/health', (req, res) => res.json({ ok: true, videos: scan().length }));

app.get('/api/videos', auth, (req, res) => {
  const q = String(req.query.q || '').toLowerCase().slice(0, 80);
  const items = scan()
    .filter(v => !q || v.title.toLowerCase().includes(q))
    .map(({ id, title, year, poster, qualities }) => ({ id, title, year, poster, qualityCount: qualities.length }));
  res.json({ success: true, total: items.length, items });
});

app.get('/api/videos/:id', auth, (req, res) => {
  const v = scan().find(x => x.id === req.params.id);
  if (!v) return res.status(404).json({ success: false, error: 'Video not found' });
  const { addedAt, ...out } = v;
  res.json({ success: true, ...out });
});

// Your own files. express.static handles Range requests -> ExoPlayer can seek.
app.use('/media', auth, express.static(MEDIA_DIR, {
  acceptRanges: true,
  fallthrough: false,
  dotfiles: 'deny',
  maxAge: '1h',
  setHeaders(res, p) {
    if (HLS_EXT.test(p)) res.setHeader('Content-Type', 'application/vnd.apple.mpegurl');
    else if (p.endsWith('.ts')) res.setHeader('Content-Type', 'video/mp2t');
    else if (p.endsWith('.m4s')) res.setHeader('Content-Type', 'video/iso.segment');
  }
}));

app.use((err, req, res, next) => res.status(err.status || 500).json({ success: false, error: err.status === 404 ? 'File not found' : err.message }));

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Cinedor personal server on port ${PORT}`);
  console.log(`Media folder: ${MEDIA_DIR}`);
  console.log(`App base URL: ${PUBLIC_BASE_URL}${APP_TOKEN ? '  (token lock ON)' : ''}`);
});
