package com.cinedor.app

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.app.PictureInPictureParams
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.util.Rational
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {

    companion object {
        const val HOST = "appassets.androidplatform.net"
        const val START_URL = "https://$HOST/assets/www/index.html"
        const val BG = 0xFF0E0F12.toInt()
    }

    private lateinit var web: WebView
    private lateinit var root: FrameLayout
    private lateinit var assetLoader: WebViewAssetLoader
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var customView: View? = null
    private var customCallback: WebChromeClient.CustomViewCallback? = null
    private var updateId = -1L
    private lateinit var chrome: WebChromeClient
    private var pendingInstall: File? = null
    @Volatile private var isPlaying = false

    private val dlDir: File by lazy { (getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: File(filesDir, "movies")).apply { mkdirs() } }
    private val updDir: File by lazy { (getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: File(filesDir, "upd")).apply { mkdirs() } }
    private val dm: DownloadManager by lazy { getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager }

    private val filePicker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val cb = fileCallback
        fileCallback = null
        cb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res.resultCode, res.data))
    }

    private val downloadReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val id = i.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1)
            if (id != -1L && id == updateId) {
                val f = File(updDir, "cinedor-update.apk")
                if (statusOf(id) == DownloadManager.STATUS_SUCCESSFUL && f.exists()) installApk(f)
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG

        root = FrameLayout(this)
        root.setBackgroundColor(BG)
        web = WebView(this)
        web.setBackgroundColor(BG)
        root.addView(web, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)

        assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            allowContentAccess = true
            loadWithOverviewMode = true
            useWideViewPort = true
            userAgentString = "$userAgentString CinedorApp/${BuildConfig.VERSION_NAME}"
        }
        web.addJavascriptInterface(Bridge(), "Android")

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val u = request.url
                if (u.host == HOST && (u.path ?: "").startsWith("/dl/")) return serveDownload(u, request.requestHeaders)
                return assetLoader.shouldInterceptRequest(u)
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                if (u.host == HOST) return false
                if (request.isForMainFrame) {
                    openExternal(u.toString())
                    return true
                }
                return false
            }
        }

        chrome = object : WebChromeClient() {
            override fun onShowFileChooser(view: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = cb
                return try {
                    val intent = params.createIntent()
                    if (params.acceptTypes.any { it.startsWith("video") }) intent.type = "video/*" else intent.type = "*/*"
                    filePicker.launch(intent)
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    false
                }
            }

            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                if (customView != null) { callback.onCustomViewHidden(); return }
                customView = view
                customCallback = callback
                root.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                web.visibility = View.GONE
                setFullscreen(true)
            }

            override fun onHideCustomView() {
                customView?.let { root.removeView(it) }
                customView = null
                web.visibility = View.VISIBLE
                customCallback?.onCustomViewHidden()
                customCallback = null
                setFullscreen(false)
            }
        }
        web.webChromeClient = chrome

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (customView != null) { chrome.onHideCustomView(); return }
                web.evaluateJavascript("(window.cinedorBack && window.cinedorBack()) ? '1' : '0'") { r ->
                    if (r == null || !r.contains("1")) finish()
                }
            }
        })

        ContextCompat.registerReceiver(this, downloadReceiver, IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE), ContextCompat.RECEIVER_EXPORTED)

        if (savedInstanceState != null) web.restoreState(savedInstanceState) else web.loadUrl(START_URL)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
        val f = pendingInstall
        if (f != null && (Build.VERSION.SDK_INT < 26 || packageManager.canRequestPackageInstalls())) {
            pendingInstall = null
            installApk(f)
        }
    }

    override fun onPause() {
        super.onPause()
        if (Build.VERSION.SDK_INT < 24 || !isInPictureInPictureMode) web.onPause()
    }

    override fun onDestroy() {
        try { unregisterReceiver(downloadReceiver) } catch (_: Exception) {}
        web.destroy()
        super.onDestroy()
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (isPlaying) enterPip()
    }

    override fun onPictureInPictureModeChanged(isInPip: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPip, newConfig)
        js("window.onPip && window.onPip($isInPip)")
    }

    private fun js(code: String) = runOnUiThread { web.evaluateJavascript(code, null) }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT >= 26) {
            try {
                enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build())
            } catch (_: Exception) {}
        }
    }

    private fun setFullscreen(on: Boolean) {
        val c = WindowCompat.getInsetsController(window, window.decorView)
        if (on) {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            c.hide(WindowInsetsCompat.Type.systemBars())
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        } else {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            c.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    private fun openExternal(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { Toast.makeText(this, "No app to open link", Toast.LENGTH_SHORT).show() }
    }

    private fun statusOf(id: Long): Int {
        dm.query(DownloadManager.Query().setFilterById(id)).use { c ->
            if (c != null && c.moveToFirst()) return c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
        }
        return -1
    }

    private fun installApk(f: File) {
        if (Build.VERSION.SDK_INT >= 26 && !packageManager.canRequestPackageInstalls()) {
            pendingInstall = f
            Toast.makeText(this, "Allow install from Cinedor, then come back", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
            return
        }
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    }

    /* Serve downloaded videos to the WebView with HTTP Range support (so seeking works offline) */
    private fun serveDownload(u: Uri, headers: Map<String, String>): WebResourceResponse {
        val name = u.lastPathSegment ?: ""
        val f = File(dlDir, name)
        if (name.isEmpty() || !f.exists() || f.parentFile?.canonicalPath != dlDir.canonicalPath) {
            return WebResourceResponse("text/plain", "utf-8", 404, "Not Found", mapOf(), ByteArrayInputStream(ByteArray(0)))
        }
        val len = f.length()
        val mime = when (f.extension.lowercase()) {
            "webm" -> "video/webm"; "ogv" -> "video/ogg"; "mkv" -> "video/x-matroska"; "m4v" -> "video/mp4"; else -> "video/mp4"
        }
        val range = headers.entries.firstOrNull { it.key.equals("Range", true) }?.value
        var start = 0L
        var end = len - 1
        if (range != null && range.startsWith("bytes=")) {
            val p = range.removePrefix("bytes=").split("-")
            start = p.getOrNull(0)?.toLongOrNull() ?: 0L
            p.getOrNull(1)?.toLongOrNull()?.let { end = minOf(it, len - 1) }
        }
        if (start >= len) start = 0
        val count = end - start + 1
        val fis = FileInputStream(f)
        fis.channel.position(start)
        val h = mutableMapOf(
            "Accept-Ranges" to "bytes",
            "Content-Length" to count.toString(),
            "Access-Control-Allow-Origin" to "*"
        )
        return if (range != null) {
            h["Content-Range"] = "bytes $start-$end/$len"
            WebResourceResponse(mime, null, 206, "Partial Content", h, Bounded(fis, count))
        } else {
            WebResourceResponse(mime, null, 200, "OK", h, Bounded(fis, count))
        }
    }

    private class Bounded(private val inner: InputStream, private var left: Long) : InputStream() {
        override fun read(): Int {
            if (left <= 0) return -1
            val r = inner.read()
            if (r >= 0) left--
            return r
        }
        override fun read(b: ByteArray, off: Int, len: Int): Int {
            if (left <= 0) return -1
            val n = inner.read(b, off, minOf(len.toLong(), left).toInt())
            if (n > 0) left -= n
            return n
        }
        override fun close() = inner.close()
    }

    /* ===================== JS bridge (window.Android) ===================== */
    inner class Bridge {
        @JavascriptInterface fun getVersionName(): String = BuildConfig.VERSION_NAME
        @JavascriptInterface fun getVersionCode(): Int = BuildConfig.VERSION_CODE

        @JavascriptInterface fun httpGet(id: Int, url: String, headersJson: String) {
            Thread {
                var ok = false
                var body: String
                try {
                    val c = URL(url).openConnection() as HttpURLConnection
                    c.connectTimeout = 15000
                    c.readTimeout = 30000
                    c.setRequestProperty("User-Agent", "CinedorApp/${BuildConfig.VERSION_NAME}")
                    val hj = JSONObject(if (headersJson.isBlank()) "{}" else headersJson)
                    hj.keys().forEach { k -> c.setRequestProperty(k, hj.getString(k)) }
                    val code = c.responseCode
                    val stream = if (code in 200..299) c.inputStream else c.errorStream
                    body = stream?.bufferedReader()?.use { it.readText() } ?: ""
                    ok = code in 200..299
                    if (!ok) body = "HTTP $code"
                } catch (e: Exception) {
                    body = e.message ?: "error"
                }
                js("window.__nativeHttp($id, $ok, ${JSONObject.quote(body)})")
            }.start()
        }

        @JavascriptInterface fun openExternal(url: String) = runOnUiThread { this@MainActivity.openExternal(url) }

        @JavascriptInterface fun share(text: String) = runOnUiThread {
            try {
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), "Share"))
            } catch (_: Exception) {}
        }

        @JavascriptInterface fun toast(msg: String) = runOnUiThread { Toast.makeText(this@MainActivity, msg, Toast.LENGTH_SHORT).show() }

        @JavascriptInterface fun download(url: String, fileName: String, title: String): String {
            val safe = fileName.replace(Regex("[^\\w.\\-]+"), "_").take(120)
            File(dlDir, safe).let { if (it.exists()) it.delete() }
            val req = DownloadManager.Request(Uri.parse(url))
                .setTitle(title)
                .setDescription("Cinedor")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalFilesDir(this@MainActivity, Environment.DIRECTORY_MOVIES, safe)
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(true)
            dm.enqueue(req)
            return safe
        }

        @JavascriptInterface fun listDownloads(): String {
            val arr = JSONArray()
            val seen = HashSet<String>()
            try {
                dm.query(DownloadManager.Query()).use { c ->
                    while (c != null && c.moveToNext()) {
                        val local = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_URI)) ?: continue
                        val path = Uri.parse(local).path ?: continue
                        val f = File(path)
                        if (f.parentFile?.canonicalPath != dlDir.canonicalPath) continue
                        val st = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                        if (st == DownloadManager.STATUS_SUCCESSFUL && !f.exists()) continue
                        if (!seen.add(f.name)) continue
                        arr.put(JSONObject()
                            .put("name", f.name)
                            .put("id", c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_ID)))
                            .put("size", c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)))
                            .put("total", c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)))
                            .put("status", when (st) {
                                DownloadManager.STATUS_SUCCESSFUL -> "done"
                                DownloadManager.STATUS_FAILED -> "failed"
                                else -> "running"
                            }))
                    }
                }
            } catch (_: Exception) {}
            dlDir.listFiles()?.forEach { f ->
                if (f.isFile && seen.add(f.name)) arr.put(JSONObject().put("name", f.name).put("size", f.length()).put("total", f.length()).put("status", "done"))
            }
            return arr.toString()
        }

        @JavascriptInterface fun deleteDownload(name: String): Boolean {
            try {
                dm.query(DownloadManager.Query()).use { c ->
                    while (c != null && c.moveToNext()) {
                        val local = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_URI)) ?: continue
                        if (Uri.parse(local).lastPathSegment == name) dm.remove(c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_ID)))
                    }
                }
            } catch (_: Exception) {}
            val f = File(dlDir, name)
            return if (f.parentFile?.canonicalPath == dlDir.canonicalPath) f.delete() || !f.exists() else false
        }

        @JavascriptInterface fun downloadUpdate(url: String) {
            val f = File(updDir, "cinedor-update.apk")
            if (f.exists()) f.delete()
            val req = DownloadManager.Request(Uri.parse(url))
                .setTitle("Cinedor update")
                .setMimeType("application/vnd.android.package-archive")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE)
                .setDestinationInExternalFilesDir(this@MainActivity, Environment.DIRECTORY_DOWNLOADS, "cinedor-update.apk")
            updateId = dm.enqueue(req)
        }

        @JavascriptInterface fun updateProgress(): Int {
            if (updateId == -1L) return -1
            dm.query(DownloadManager.Query().setFilterById(updateId)).use { c ->
                if (c != null && c.moveToFirst()) {
                    val st = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                    if (st == DownloadManager.STATUS_SUCCESSFUL) return 100
                    if (st == DownloadManager.STATUS_FAILED) return -2
                    val done = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                    val total = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                    return if (total > 0) minOf(99, (done * 100 / total).toInt()) else 0
                }
            }
            return -1
        }

        @JavascriptInterface fun enterPip() = runOnUiThread { this@MainActivity.enterPip() }
        @JavascriptInterface fun setFullscreen(on: Boolean) = runOnUiThread { this@MainActivity.setFullscreen(on) }
        @JavascriptInterface fun setPlaying(on: Boolean) { isPlaying = on }

        @JavascriptInterface fun keepScreenOn(on: Boolean) = runOnUiThread {
            if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }

        @JavascriptInterface fun setBarColors(light: Boolean) = runOnUiThread {
            val color = if (light) Color.parseColor("#F6F5FA") else BG
            window.statusBarColor = color
            window.navigationBarColor = color
            root.setBackgroundColor(color)
            WindowCompat.getInsetsController(window, window.decorView).apply {
                isAppearanceLightStatusBars = light
                isAppearanceLightNavigationBars = light
            }
        }
    }
}
