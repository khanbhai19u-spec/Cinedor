/* ===================================================================
   Cinedor — app logic
   TMDB = movie info / posters / trailers (auto)
   Internet Archive = free public-domain movies & cartoons (play + download)
   My Videos = user's own files on the phone
   =================================================================== */
'use strict';
const CFG = Object.assign({ tmdbKey: '', repo: '' }, window.CINEDOR_CONFIG || {});
const A = window.Android || null;              // native bridge (Android app)
const APP_NAME = 'Cinedor';

/* ---------- storage ---------- */
const store = {
  get(k, d){ try{ const v = localStorage.getItem('cd_'+k); return v === null ? d : JSON.parse(v); }catch(e){ return d; } },
  set(k, v){ try{ localStorage.setItem('cd_'+k, JSON.stringify(v)); }catch(e){} }
};
const S = {
  key: store.get('key', '') || CFG.tmdbKey,
  lang: store.get('lang', 'bn'),
  theme: store.get('theme', 'dark'),
  name: store.get('name', 'Bayzid'),
  list: store.get('list', []),
  hist: store.get('hist', {}),
  recent: store.get('recent', []),
  dls: store.get('dls', {}),
  subSize: store.get('subSize', 'm'),
  listCfg: null
};

/* ---------- text ---------- */
const T = {
  bn:{home:'হোম',explore:'এক্সপ্লোর',anime:'অ্যানিমে',profile:'প্রোফাইল',hello:'আজ কী দেখবেন?',seeAll:'সব দেখুন',watch:'দেখুন',trailer:'ট্রেইলার',play:'প্লে',myList:'আমার লিস্ট',download:'ডাউনলোড',rate:'রেটিং',share:'শেয়ার',story:'কাহিনি',cast:'অভিনয়ে',where:'কোথায় দেখবেন',similar:'এরকম আরও',episodes:'এপিসোড',seasons:'সিজন',noTrailer:'ট্রেইলার পাওয়া যায়নি',noProv:'আপনার দেশে এখনো কোনো স্ট্রিমিং সার্ভিসে নেই',error:'লোড হয়নি। ইন্টারনেট বা API key চেক করুন।',retry:'আবার চেষ্টা',noRes:'কিছু পাওয়া যায়নি',added:'লিস্টে যোগ হয়েছে',removed:'লিস্ট থেকে সরানো হয়েছে',showMore:'আরও দেখুন',showLess:'কম দেখুন',cont:'দেখা চালিয়ে যান',top10:'আজকের টপ ১০',freeMovies:'ফ্রি ক্লাসিক মুভি',freeCartoons:'ফ্রি কার্টুন',bangla:'বাংলা মুভি',popMovies:'জনপ্রিয় মুভি',popTv:'জনপ্রিয় সিরিজ',hindi:'হিন্দি মুভি',now:'এখন সিনেমা হলে',up:'শীঘ্রই আসছে',topRated:'সেরা রেটিং',searchPh:'মুভি, সিরিজ, অভিনেতা…',byLang:'ভাষা অনুযায়ী',genres:'ঘরানা',recent:'আগের সার্চ',freeFound:'ফ্রি তে দেখুন (Internet Archive)',freeCard:'ফ্রি তে পুরো মুভি দেখুন',freeCardSub:'পাবলিক ডোমেইন · Internet Archive',library:'লাইব্রেরি',settings:'সেটিংস',downloads:'ডাউনলোড',history:'দেখার ইতিহাস',myVideos:'আমার ভিডিও',phoneFiles:'ফোনের ফাইল',language:'ভাষা',theme:'থিম',dark:'ডার্ক',light:'লাইট',auto:'অটো',apiKey:'TMDB API Key',checkUpd:'আপডেট চেক করুন',about:'Cinedor সম্পর্কে',watched:'দেখা',keyNeeded:'TMDB API key দিন',keyHelp:'GitHub-এর TMDB_API_KEY secret-এ দিলে অটো বসে যায়। এখানে দিলে শুধু এই ফোনে কাজ করবে।',save:'সেভ',cancel:'বাতিল',saved:'সেভ হয়েছে',latest:'আপনি সর্বশেষ ভার্সনে আছেন',newUpd:'নতুন আপডেট এসেছে!',updNow:'এখনই আপডেট',later:'পরে',updating:'আপডেট ডাউনলোড হচ্ছে…',noDl:'এখনো কিছু ডাউনলোড করা হয়নি',noHist:'এখনো কিছু দেখা হয়নি',emptyList:'লিস্ট খালি। যেকোনো মুভিতে + চাপুন।',chooseQ:'কোয়ালিটি বাছুন',dlStarted:'ডাউনলোড শুরু হয়েছে',quality:'কোয়ালিটি',speed:'স্পিড',subs:'সাবটাইটেল',subStyle:'সাবটাইটেল সাইজ',sleep:'স্লিপ টাইমার',aspect:'স্ক্রিন সাইজ',off:'বন্ধ',loadSub:'ফোন থেকে .srt দিন',done:'ঠিক আছে',fit:'ফিট',fill:'ফিল',stretch:'স্ট্রেচ',endOf:'শেষ হলে',min:'মিনিট',locked:'স্ক্রিন লক',editName:'নাম বদলান',free:'FREE',movies:'মুভি',series:'সিরিজ',forYou:'আপনার জন্য',kTrend:'ট্রেন্ডিং কে-ড্রামা',kTop:'সেরা কে-ড্রামা',kNew:'নতুন সিজন',kCrime:'ক্রাইম ও মিস্ট্রি',kFantasy:'ফ্যান্টাসি',kComedy:'কমেডি',kMovies:'কোরিয়ান মুভি',aPop:'জনপ্রিয় অ্যানিমে',aTop:'সর্বকালের সেরা',aNew:'নতুন অ্যানিমে',aMovies:'অ্যানিমে মুভি',aAction:'অ্যাকশন',aFantasy:'ফ্যান্টাসি',aComedy:'কমেডি',greetM:'শুভ সকাল',greetA:'শুভ দুপুর',greetE:'শুভ সন্ধ্যা',greetN:'শুভ রাত্রি',version:'ভার্সন'},
  en:{home:'Home',explore:'Explore',anime:'Anime',profile:'Profile',hello:'What to watch today?',seeAll:'See all',watch:'Watch',trailer:'Trailer',play:'Play',myList:'My List',download:'Download',rate:'Rate',share:'Share',story:'Story',cast:'Cast',where:'Where to Watch',similar:'More Like This',episodes:'Episodes',seasons:'Seasons',noTrailer:'No trailer available',noProv:'Not on streaming in your region yet',error:'Could not load. Check internet or API key.',retry:'Retry',noRes:'Nothing found',added:'Added to My List',removed:'Removed from My List',showMore:'Show more',showLess:'Show less',cont:'Continue Watching',top10:'Top 10 Today',freeMovies:'Free Classic Movies',freeCartoons:'Free Cartoons',bangla:'Bangla Movies',popMovies:'Popular Movies',popTv:'Popular Series',hindi:'Hindi Movies',now:'Now in Cinemas',up:'Coming Soon',topRated:'Top Rated',searchPh:'Movies, series, actors…',byLang:'Browse by Language',genres:'Genres',recent:'Recent Searches',freeFound:'Watch free (Internet Archive)',freeCard:'Watch the full movie free',freeCardSub:'Public domain · Internet Archive',library:'Library',settings:'Settings',downloads:'Downloads',history:'Watch History',myVideos:'My Videos',phoneFiles:'Phone files',language:'Language',theme:'Theme',dark:'Dark',light:'Light',auto:'Auto',apiKey:'TMDB API Key',checkUpd:'Check for update',about:'About Cinedor',watched:'Watched',keyNeeded:'Add TMDB API key',keyHelp:'Set the TMDB_API_KEY secret on GitHub and it is added automatically. A key here works on this phone only.',save:'Save',cancel:'Cancel',saved:'Saved',latest:'You are on the latest version',newUpd:'New update available!',updNow:'Update now',later:'Later',updating:'Downloading update…',noDl:'No downloads yet',noHist:'Nothing watched yet',emptyList:'Your list is empty. Tap + on any movie.',chooseQ:'Choose quality',dlStarted:'Download started',quality:'Quality',speed:'Speed',subs:'Subtitles',subStyle:'Subtitle size',sleep:'Sleep timer',aspect:'Aspect',off:'Off',loadSub:'Load .srt from phone',done:'Done',fit:'Fit',fill:'Fill',stretch:'Stretch',endOf:'End of video',min:'min',locked:'Screen locked',editName:'Edit name',free:'FREE',movies:'Movies',series:'Series',forYou:'For You',kTrend:'Trending K-Drama',kTop:'Top Rated K-Drama',kNew:'New This Season',kCrime:'Crime & Mystery',kFantasy:'Fantasy',kComedy:'Comedy',kMovies:'Korean Movies',aPop:'Popular Anime',aTop:'All-Time Best',aNew:'New Anime',aMovies:'Anime Movies',aAction:'Action',aFantasy:'Fantasy',aComedy:'Comedy',greetM:'Good morning',greetA:'Good afternoon',greetE:'Good evening',greetN:'Good night',version:'Version'}
};
const t = k => (T[S.lang] || T.en)[k] || T.en[k] || k;

/* ---------- helpers ---------- */
const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const img = (p, size='w342') => p ? `https://image.tmdb.org/t/p/${size}${p}` : '';
const iaImg = id => `https://archive.org/services/img/${encodeURIComponent(id)}`;
const yr = m => (m.release_date || m.first_air_date || '').slice(0,4);
const ttl = m => m.title || m.name || '';
const typeOf = (m, fb) => (m.media_type === 'tv' || m.media_type === 'movie') ? m.media_type : (fb || ((m.first_air_date !== undefined || (m.name && !m.title)) ? 'tv' : 'movie'));
const BN = '০১২৩৪৫৬৭৮৯';
const num = v => S.lang === 'bn' ? String(v ?? '').replace(/\d/g, d => BN[d]) : String(v ?? '');
const fmtT = s => { s = Math.max(0, Math.floor(s || 0)); const h = Math.floor(s/3600), m = Math.floor(s%3600/60), x = s%60; return (h ? h+':'+String(m).padStart(2,'0') : m) + ':' + String(x).padStart(2,'0'); };
const fmtSize = b => { b = +b || 0; if(b > 1e9) return (b/1e9).toFixed(2)+' GB'; if(b > 1e6) return (b/1e6).toFixed(0)+' MB'; return (b/1e3).toFixed(0)+' KB'; };
const today = () => new Date().toISOString().slice(0,10);
const stripHtml = h => { const d = document.createElement('div'); d.innerHTML = String(h||'').replace(/<br\s*\/?>/gi,'\n'); return (d.textContent||'').trim(); };
const ICON = {
  play:'<svg class="i" viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M7 4.5v15l12-7.5z"/></svg>',
  pause:'<svg viewBox="0 0 24 24"><rect x="6" y="4.5" width="4" height="15" rx="1.2"/><rect x="14" y="4.5" width="4" height="15" rx="1.2"/></svg>',
  playF:'<svg viewBox="0 0 24 24"><path d="M8 4.5v15l12-7.5z"/></svg>',
  plus:'<svg class="i" viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>',
  check:'<svg class="i" viewBox="0 0 24 24"><path d="m5 12.5 4.5 4.5L19 7"/></svg>',
  back:'<svg class="i" viewBox="0 0 24 24"><path d="M15 5 8 12l7 7"/></svg>',
  search:'<svg class="i" viewBox="0 0 24 24"><circle cx="10.5" cy="10.5" r="6.5"/><path d="m15.5 15.5 5 5"/></svg>',
  dl:'<svg class="i" viewBox="0 0 24 24"><path d="M12 4v11m-5-5 5 5 5-5"/><path d="M5 20h14"/></svg>',
  share:'<svg class="i" viewBox="0 0 24 24"><circle cx="18" cy="5.5" r="2.5"/><circle cx="6" cy="12" r="2.5"/><circle cx="18" cy="18.5" r="2.5"/><path d="m8.2 10.8 7.6-4.1M8.2 13.2l7.6 4.1"/></svg>',
  rate:'<svg class="i" viewBox="0 0 24 24"><path d="M12 3.5l2.6 5.4 5.9.8-4.3 4.1 1 5.8L12 16.9l-5.2 2.7 1-5.8-4.3-4.1 5.9-.8z"/></svg>',
  trailer:'<svg class="i" viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="3"/><path d="M10 9.5v5l4-2.5z"/></svg>',
  trash:'<svg class="i" viewBox="0 0 24 24"><path d="M4 7h16M9 7V4.5h6V7M6.5 7l1 13h9l1-13"/></svg>',
  bell:'<svg class="i" viewBox="0 0 24 24"><path d="M6 16V11a6 6 0 0 1 12 0v5l1.5 2h-15z"/><path d="M10 20.5a2 2 0 0 0 4 0"/></svg>',
  edit:'<svg class="i" viewBox="0 0 24 24"><path d="M4 20h4L19 9l-4-4L4 16z"/></svg>',
  chev:'›'
};
const LOGO = '<svg viewBox="8 8 104 104" aria-hidden="true"><defs><linearGradient id="lg" x1="0.2" y1="0" x2="0.8" y2="1"><stop offset="0" stop-color="#A78BFA"/><stop offset="0.5" stop-color="#C026D3"/><stop offset="1" stop-color="#EC4899"/></linearGradient></defs><g transform="translate(0 -3)"><path d="M30 100V56a30 30 0 0 1 60 0v44" fill="none" stroke="url(#lg)" stroke-width="16" stroke-linecap="round"/><path d="M52 61q0-4.6 4-2.3l17.4 10.6q4 2.3 0 4.6L56 84.6q-4 2.3-4-2.3z" fill="url(#lg)"/></g></svg>';

function toast(m){ const el = $('#toast'); el.textContent = m; el.classList.add('on'); clearTimeout(toast._t); toast._t = setTimeout(() => el.classList.remove('on'), 2000); }
document.addEventListener('load', e => { if(e.target.tagName === 'IMG') e.target.classList.add('ld'); }, true);
document.addEventListener('error', e => { if(e.target.tagName === 'IMG' && e.target.closest('.pimg')){ e.target.remove(); } }, true);

/* ---------- network (fetch, with native fallback for CORS) ---------- */
const pending = {}; let nseq = 0;
window.__nativeHttp = (id, ok, body) => { const p = pending[id]; if(!p) return; delete pending[id]; ok ? p.res(body) : p.rej(new Error(body)); };
function nativeGet(url, headers){ return new Promise((res, rej) => { const id = ++nseq; pending[id] = { res, rej }; A.httpGet(id, url, JSON.stringify(headers || {})); setTimeout(() => { if(pending[id]){ delete pending[id]; rej(new Error('timeout')); } }, 30000); }); }
async function getText(url, headers){
  try{
    const r = await fetch(url, { headers: headers || {} });
    if(!r.ok) throw new Error('HTTP ' + r.status);
    return await r.text();
  }catch(e){
    if(A && A.httpGet && !String(e.message).startsWith('HTTP')) return nativeGet(url, headers);
    throw e;
  }
}
const getJSON = async (url, headers) => JSON.parse(await getText(url, headers));

/* ---------- TMDB ---------- */
const cache = new Map();
function tmdb(path, params = {}){
  if(!S.key) return Promise.reject(new Error('nokey'));
  const p = new URLSearchParams({ language: S.lang === 'bn' ? 'bn-BD' : 'en-US', ...params });
  const bearer = S.key.length > 60;
  if(!bearer) p.set('api_key', S.key);
  const url = 'https://api.themoviedb.org/3' + path + '?' + p;
  if(cache.has(url)) return cache.get(url);
  const pr = getJSON(url, bearer ? { Authorization: 'Bearer ' + S.key, accept: 'application/json' } : null);
  cache.set(url, pr); pr.catch(() => cache.delete(url));
  return pr;
}

/* ---------- Internet Archive (free, public domain) ---------- */
function iaSearch(q, page = 1, rows = 30, sort = 'downloads desc'){
  const p = new URLSearchParams({ q, rows, page, output: 'json' });
  ['identifier','title','year','downloads'].forEach(f => p.append('fl[]', f));
  if(sort) p.append('sort[]', sort);
  const url = 'https://archive.org/advancedsearch.php?' + p;
  if(cache.has(url)) return cache.get(url);
  const pr = getJSON(url).then(d => ({ items: (d.response?.docs || []), total: d.response?.numFound || 0 }));
  cache.set(url, pr); pr.catch(() => cache.delete(url));
  return pr;
}
const IA_MOVIES = 'collection:(feature_films) AND mediatype:(movies)';
const IA_CARTOONS = 'collection:(animationandcartoons) AND mediatype:(movies)';
function iaMeta(id){
  const url = 'https://archive.org/metadata/' + encodeURIComponent(id);
  if(cache.has(url)) return cache.get(url);
  const pr = getJSON(url); cache.set(url, pr); pr.catch(() => cache.delete(url));
  return pr;
}
function iaVideos(meta){
  const files = meta.files || [];
  const vids = files.filter(f => /\.(mp4|m4v|webm|ogv|mkv)$/i.test(f.name) && !/^__ia_thumb/.test(f.name));
  const groups = {};
  vids.forEach(f => { const k = (f.source === 'derivative' && f.original) ? f.original : f.name; (groups[k] = groups[k] || []).push(f); });
  const base = `https://archive.org/download/${encodeURIComponent(meta.metadata.identifier)}/`;
  const eps = Object.keys(groups).map(k => {
    const vs = groups[k]
      .filter(f => !/\.mkv$/i.test(f.name) || groups[k].length === 1)
      .map(f => ({ url: base + f.name.split('/').map(encodeURIComponent).join('/'), size: +f.size || 0, label: (f.height ? f.height + 'p' : (f.format || 'Video').replace(/^h\.264( IA)?$/i,'HD').replace(/^512Kb MPEG4$/i,'SD').replace(/^MPEG4$/i,'HD')), name: f.name, mp4: /\.mp4$/i.test(f.name) }))
      .sort((a,b) => (b.mp4 - a.mp4) || (b.size - a.size));
    return { title: (files.find(f => f.name === k)?.title) || k.replace(/\.[^.]+$/,'').replace(/[_]+/g,' '), sources: vs, key: k };
  }).filter(e => e.sources.length).sort((a,b) => a.key.localeCompare(b.key, undefined, { numeric:true }));
  const subs = files.filter(f => /\.(srt|vtt)$/i.test(f.name)).map(f => ({ label: f.name.replace(/\.[^.]+$/,'').split(/[._]/).pop() || 'Sub', url: base + f.name.split('/').map(encodeURIComponent).join('/'), kind: /\.vtt$/i.test(f.name) ? 'vtt' : 'srt' }));
  return { eps, subs };
}

/* ---------- cards ---------- */
function card(m, fb, opts = {}){
  const type = typeOf(m, fb), title = ttl(m);
  return `<div class="card" data-go="${type}-${m.id}">
    <div class="pimg">${m.poster_path ? `<img loading="lazy" src="${img(m.poster_path)}" alt="">` : `<div class="noimg">${esc(title)}</div>`}
    ${opts.rank ? `<span class="rank">${num(opts.rank)}</span>` : `<span class="rate">★ ${(m.vote_average||0).toFixed(1)}</span>`}
    ${type === 'tv' && !opts.rank ? `<span class="tvb">${esc(t('series'))}</span>` : ''}</div>
    <div class="ct">${esc(title)}</div><div class="cy">${num(yr(m))}</div></div>`;
}
function iaCard(d){
  return `<div class="card" data-go="ia-${esc(d.identifier)}">
    <div class="pimg"><img loading="lazy" src="${iaImg(d.identifier)}" alt=""><span class="free">${t('free')}</span></div>
    <div class="ct">${esc(d.title || d.identifier)}</div><div class="cy">${num(d.year || '')}</div></div>`;
}
const skCards = n => Array.from({ length: n }, () => `<div class="card"><div class="pimg sk"></div><div class="ct sk" style="height:12px;border-radius:6px;width:80%"></div></div>`).join('');
const errBox = fn => `<div class="err">${esc(t('error'))}<br><button class="gbtn" onclick="${fn}">${esc(t('retry'))}</button></div>`;

/* ---------- row sources ---------- */
function rowLoader(r){
  if(r.src === 'ia') return page => iaSearch(r.q, page, 30).then(d => ({ html: d.items.map(iaCard), pages: Math.ceil(d.total / 30) }));
  return page => tmdb(r.path, { ...r.params, page }).then(d => ({
    html: (d.results || []).filter(m => m.media_type !== 'person' && (r.grid || m.poster_path)).map(m => card(m, r.type)),
    pages: Math.min(d.total_pages || 1, 500)
  }));
}
function infiniteGrid(container, loader){
  container.innerHTML = `<div class="grid"></div><div class="sentinel"><div class="spin"></div></div>`;
  const grid = container.querySelector('.grid'), sent = container.querySelector('.sentinel');
  let page = 0, pages = 1, busy = false;
  const tok = (container._tok = Symbol());
  async function more(){
    if(busy || page >= pages || container._tok !== tok) return;
    busy = true;
    try{
      const d = await loader(page + 1);
      if(container._tok !== tok) return;
      page++; pages = d.pages || 1;
      grid.insertAdjacentHTML('beforeend', d.html.join(''));
      if(page === 1 && !d.html.length) grid.outerHTML = `<div class="empty">${esc(t('noRes'))}</div>`;
      if(page >= pages) sent.innerHTML = '';
    }catch(e){ sent.innerHTML = `<div class="cy">${esc(t('error'))}</div>`; pages = page; }
    busy = false;
    if(page < pages && sent.getBoundingClientRect().top < innerHeight + 400) more();
  }
  new IntersectionObserver(es => { if(es[0].isIntersecting) more(); }, { rootMargin: '500px' }).observe(sent);
  more();
}
function openList(r){ S.listCfg = r; if(location.hash === '#list') renderList(); else location.hash = 'list'; }

/* ---------- rows page (Home / K-Drama / Anime) ---------- */
function rowsHTML(rows, prefix){
  return rows.map((r, i) => `<div class="row"><div class="rowh"><h2 class="${/[ঀ-৿]/.test(t(r.k)) ? 'bn' : ''}">${esc(t(r.k))}</h2><button class="see" data-row="${prefix}:${i}">${esc(t('seeAll'))} ›</button></div><div class="scroller" id="${prefix}${i}">${skCards(5)}</div></div>`).join('');
}
function fillRows(rows, prefix){
  rows.forEach((r, i) => rowLoader(r)(1).then(d => {
    const el = document.getElementById(prefix + i); if(!el) return;
    let html = d.html;
    if(r.rank) html = html.slice(0, 10).map((h, j) => h.replace(/<span class="rate">[^<]*<\/span>/, `<span class="rank">${num(j + 1)}</span>`).replace(/<span class="tvb">[^<]*<\/span>/, ''));
    el.innerHTML = html.length ? html.join('') : `<div class="cy" style="padding:10px 0">${esc(t('noRes'))}</div>`;
  }).catch(() => { const el = document.getElementById(prefix + i); if(el) el.innerHTML = `<div class="cy">${esc(t('error'))}</div>`; }));
}
const ROWSETS = {};
function heroHTML(id){ return `<div class="hero sk" id="${id}"></div><div class="dots" id="${id}d"></div>`; }
let heroTimers = {};
async function loadHero(id, path, params, fb){
  const h = document.getElementById(id), dots = document.getElementById(id + 'd');
  try{
    const d = await tmdb(path, params);
    const items = (d.results || []).filter(m => m.backdrop_path && m.media_type !== 'person').slice(0, 6);
    if(!items.length) throw 0;
    h.classList.remove('sk');
    h.innerHTML = `<div class="track">${items.map((m, i) => { const ty = typeOf(m, fb); return `
      <div class="slide" data-go="${ty}-${m.id}"><img src="${img(m.backdrop_path, 'w780')}" alt="">
        <div class="info"><span class="tag">TRENDING #${i + 1}</span><h1>${esc(ttl(m))}</h1>
        <div class="meta">${num(yr(m))} · ${ty === 'tv' ? esc(t('series')) : esc(t('movies'))} · ★ ${(m.vote_average||0).toFixed(1)}</div>
        <div class="hb"><button class="gbtn">${ICON.play}${esc(t('watch'))}</button>
        <button class="obtn" data-mylist="${ty}-${m.id}" aria-label="my list">${inList(ty, m.id) ? ICON.check : ICON.plus}</button></div></div></div>`; }).join('')}</div>`;
    h._items = items.map(m => ({ ...m, _t: typeOf(m, fb) }));
    dots.innerHTML = items.map((_, i) => `<span class="${i ? '' : 'on'}"></span>`).join('');
    const track = h.querySelector('.track'), ds = dots.querySelectorAll('span');
    let idx = 0, sx = 0, moved = false;
    const go = i => { idx = (i + items.length) % items.length; track.style.transform = `translateX(-${idx * 100}%)`; ds.forEach((d, j) => d.classList.toggle('on', j === idx)); };
    const auto = () => { clearInterval(heroTimers[id]); heroTimers[id] = setInterval(() => { if(h.offsetParent) go(idx + 1); }, 5000); };
    h.addEventListener('touchstart', e => { sx = e.touches[0].clientX; moved = false; }, { passive: true });
    h.addEventListener('touchmove', e => { if(Math.abs(e.touches[0].clientX - sx) > 10) moved = true; }, { passive: true });
    h.addEventListener('touchend', e => { const dx = e.changedTouches[0].clientX - sx; if(Math.abs(dx) > 40){ go(idx + (dx < 0 ? 1 : -1)); auto(); } });
    h.addEventListener('click', e => { if(moved){ e.stopPropagation(); moved = false; } }, true);
    auto();
  }catch(e){ h.classList.remove('sk'); h.style.display = 'none'; }
}
function keyCardHTML(){
  return `<div class="grp" style="padding:18px;margin-top:16px"><h3 style="font-size:16px;margin-bottom:6px">🔑 ${esc(t('keyNeeded'))}</h3><p style="font-size:13px;color:var(--muted);line-height:1.6">${esc(t('keyHelp'))}</p><button class="gbtn" style="margin-top:12px" data-act="key">${esc(t('apiKey'))}</button></div>`;
}
function greet(){ const h = new Date().getHours(); return t(h < 12 ? 'greetM' : h < 16 ? 'greetA' : h < 20 ? 'greetE' : 'greetN'); }

function renderHome(){
  const v = $('#v-home');
  const rows = ROWSETS.home = [
    { k:'top10', path:'/trending/all/day', params:{}, rank:true },
    { k:'freeMovies', src:'ia', q: IA_MOVIES },
    { k:'bangla', path:'/discover/movie', params:{ with_original_language:'bn', sort_by:'popularity.desc' }, type:'movie' },
    { k:'popMovies', path:'/movie/popular', params:{}, type:'movie' },
    { k:'popTv', path:'/tv/popular', params:{}, type:'tv' },
    { k:'hindi', path:'/discover/movie', params:{ with_original_language:'hi', sort_by:'popularity.desc' }, type:'movie' },
    { k:'now', path:'/movie/now_playing', params:{}, type:'movie' },
    { k:'freeCartoons', src:'ia', q: IA_CARTOONS },
    { k:'up', path:'/movie/upcoming', params:{}, type:'movie' },
    { k:'topRated', path:'/movie/top_rated', params:{}, type:'movie' }
  ];
  const tmdbRows = S.key ? rows : rows.filter(r => r.src === 'ia');
  ROWSETS.home = tmdbRows;
  v.innerHTML = `
    <div class="topbar"><div class="brand">${LOGO}<span>${APP_NAME}</span></div>
      <div class="rbtns"><button class="cbtn" data-go="explore" aria-label="search">${ICON.search}</button><button class="cbtn" data-act="update" aria-label="updates">${ICON.bell}</button></div></div>
    <div class="hello"><small class="bn">${esc(greet())}, ${esc(S.name)} 👋</small><b class="bn">${esc(t('hello'))}</b></div>
    ${S.key ? heroHTML('h-home') : '<div style="padding:0 20px">' + keyCardHTML() + '</div>'}
    <div class="chips">
      <button class="chip on">${esc(t('forYou'))}</button>
      <button class="chip" data-chip="movies">${esc(t('movies'))}</button>
      <button class="chip" data-chip="series">${esc(t('series'))}</button>
      <button class="chip bn" data-chip="bn">বাংলা</button>
      <button class="chip" data-chip="hi">Hindi</button>
      <button class="chip" data-chip="free">${esc(t('free'))}</button>
    </div>
    <div id="contRow"></div>
    ${rowsHTML(tmdbRows, 'home')}`;
  if(S.key) loadHero('h-home', '/trending/all/day', {});
  renderContinue();
  fillRows(tmdbRows, 'home');
}
function renderContinue(){
  const el = $('#contRow'); if(!el) return;
  const items = Object.values(S.hist).filter(h => h.src && h.dur > 30 && h.pos / h.dur < 0.95).sort((a,b) => b.t - a.t).slice(0, 12);
  if(!items.length){ el.innerHTML = ''; return; }
  el.innerHTML = `<div class="row"><div class="rowh"><h2 class="bn">${esc(t('cont'))}</h2><button class="see" data-go="history">${esc(t('seeAll'))} ›</button></div>
    <div class="scroller">${items.map(h => `<div class="cw" data-resume="${esc(h.key)}"><div class="th">${h.poster ? `<img src="${esc(h.poster)}" alt="">` : ''}<div class="pl"><span>${ICON.play}</span></div><div class="bar"><i style="width:${Math.round(h.pos / h.dur * 100)}%"></i></div></div><div class="ct">${esc(h.title)}</div></div>`).join('')}</div></div>`;
}
function renderRowsTab(name, title, heroPath, heroParams, heroType, rows){
  const v = $('#v-' + name);
  ROWSETS[name] = rows;
  v.innerHTML = `<div class="ptitle">${esc(title)}</div>${S.key ? heroHTML('h-' + name) + rowsHTML(rows, name) : '<div style="padding:0 20px">' + keyCardHTML() + '</div>'}`;
  if(!S.key) return;
  loadHero('h-' + name, heroPath, heroParams, heroType);
  fillRows(rows, name);
}
function renderKdrama(){
  const ko = { with_original_language:'ko' };
  renderRowsTab('kdrama', 'K-Drama', '/discover/tv', { ...ko, sort_by:'popularity.desc' }, 'tv', [
    { k:'kTrend', path:'/discover/tv', params:{ ...ko, sort_by:'popularity.desc' }, type:'tv' },
    { k:'kNew', path:'/discover/tv', params:{ ...ko, sort_by:'first_air_date.desc', 'first_air_date.lte': today(), 'vote_count.gte': 5 }, type:'tv' },
    { k:'kTop', path:'/discover/tv', params:{ ...ko, sort_by:'vote_average.desc', 'vote_count.gte': 300 }, type:'tv' },
    { k:'kCrime', path:'/discover/tv', params:{ ...ko, with_genres:'80|9648', sort_by:'popularity.desc' }, type:'tv' },
    { k:'kFantasy', path:'/discover/tv', params:{ ...ko, with_genres:'10765', sort_by:'popularity.desc' }, type:'tv' },
    { k:'kComedy', path:'/discover/tv', params:{ ...ko, with_genres:'35', sort_by:'popularity.desc' }, type:'tv' },
    { k:'kMovies', path:'/discover/movie', params:{ ...ko, sort_by:'popularity.desc' }, type:'movie' }
  ]);
}
function renderAnime(){
  const an = { with_genres:'16', with_original_language:'ja' };
  renderRowsTab('anime', t('anime'), '/discover/tv', { ...an, sort_by:'popularity.desc' }, 'tv', [
    { k:'aPop', path:'/discover/tv', params:{ ...an, sort_by:'popularity.desc' }, type:'tv' },
    { k:'aNew', path:'/discover/tv', params:{ ...an, sort_by:'first_air_date.desc', 'first_air_date.lte': today(), 'vote_count.gte': 5 }, type:'tv' },
    { k:'aTop', path:'/discover/tv', params:{ ...an, sort_by:'vote_average.desc', 'vote_count.gte': 300 }, type:'tv' },
    { k:'aMovies', path:'/discover/movie', params:{ ...an, sort_by:'popularity.desc' }, type:'movie' },
    { k:'aAction', path:'/discover/tv', params:{ with_genres:'16,10759', with_original_language:'ja', sort_by:'popularity.desc' }, type:'tv' },
    { k:'aFantasy', path:'/discover/tv', params:{ with_genres:'16,10765', with_original_language:'ja', sort_by:'popularity.desc' }, type:'tv' },
    { k:'aComedy', path:'/discover/tv', params:{ with_genres:'16,35', with_original_language:'ja', sort_by:'popularity.desc' }, type:'tv' }
  ]);
}

/* ---------- Explore ---------- */
const LANGS = [['বাংলা','bn'],['Hindi','hi'],['English','en'],['Korean','ko'],['Tamil','ta'],['Telugu','te'],['Japanese','ja']];
const GENRES = [['Action',28,'#7F1D1D,#DC2626'],['Romance',10749,'#831843,#DB2777'],['Sci-Fi',878,'#1E3A8A,#2563EB'],['Comedy',35,'#78350F,#D97706'],['Thriller',53,'#1F2937,#4B5563'],['Fantasy',14,'#3B0764,#7C3AED'],['Animation',16,'#064E3B,#059669'],['Horror',27,'#18181B,#52525B'],['Drama',18,'#164E63,#0891B2'],['Crime',80,'#3F1D0B,#9A3412']];
let sTimer;
function renderExplore(){
  const v = $('#v-explore');
  if(v._built) return;
  v._built = true;
  v.innerHTML = `<div class="ptitle">${esc(t('explore'))}</div>
    <label class="sbox">${ICON.search}<input id="sq" type="search" placeholder="${esc(t('searchPh'))}" autocomplete="off" enterkeyhint="search"></label>
    <div id="sres"></div>
    <div id="sdef">
      <div class="sec2 bn">${esc(t('byLang'))}</div>
      <div class="chips" style="padding-top:0">${LANGS.map(([n, c]) => `<button class="chip bn" data-lang-list="${c}">${n}</button>`).join('')}</div>
      <div class="sec2 bn">${esc(t('genres'))}</div>
      <div class="tiles">${GENRES.map(([n, id, c]) => `<button class="tile" data-genre="${id}" data-gname="${n}" style="background:linear-gradient(135deg,${c})">${n}</button>`).join('')}</div>
      <div id="recentBox"></div>
    </div>`;
  renderRecent();
  const inp = $('#sq');
  inp.addEventListener('input', () => {
    clearTimeout(sTimer);
    const q = inp.value.trim();
    sTimer = setTimeout(() => doSearch(q), 400);
  });
  inp.addEventListener('change', () => { const q = inp.value.trim(); if(q.length > 1){ S.recent = [q, ...S.recent.filter(x => x !== q)].slice(0, 10); store.set('recent', S.recent); } });
}
function renderRecent(){
  const b = $('#recentBox'); if(!b) return;
  b.innerHTML = S.recent.length ? `<div class="sec2 bn">${esc(t('recent'))}</div><div class="recent">${S.recent.map(q => `<button data-recent="${esc(q)}">${esc(q)}</button>`).join('')}</div>` : '';
}
function doSearch(q){
  const res = $('#sres'), def = $('#sdef');
  if(!q){ res.innerHTML = ''; def.style.display = ''; return; }
  def.style.display = 'none';
  res.innerHTML = `<div id="sia"></div><div class="sec2">TMDB</div><div id="stm"></div>`;
  iaSearch(`title:(${q.replace(/[():"]/g, ' ')}) AND (${IA_MOVIES} OR ${IA_CARTOONS})`, 1, 12).then(d => {
    const el = $('#sia'); if(!el || !d.items.length) return;
    el.innerHTML = `<div class="sec2 bn">${esc(t('freeFound'))}</div><div class="scroller">${d.items.map(iaCard).join('')}</div>`;
  }).catch(() => {});
  if(S.key) infiniteGrid($('#stm'), page => tmdb('/search/multi', { query: q, include_adult: false, page }).then(d => ({ html: (d.results || []).filter(m => m.media_type === 'movie' || m.media_type === 'tv').map(m => card(m)), pages: Math.min(d.total_pages || 1, 50) })));
  else $('#stm').innerHTML = keyCardHTML();
}

/* ---------- List ---------- */
function renderList(){
  const c = S.listCfg, v = $('#v-list');
  if(!c){ location.hash = 'home'; return; }
  v.innerHTML = `<div class="ptitle"><button class="cbtn" data-act="back" aria-label="back">${ICON.back}</button><span class="bn">${esc(c.title || t(c.k))}</span></div><div id="lgrid"></div>`;
  if(c.custom) return c.custom($('#lgrid'));
  infiniteGrid($('#lgrid'), rowLoader({ ...c, grid: true }));
}

/* ---------- Detail (TMDB) ---------- */
async function renderDetail(type, id){
  const v = $('#v-detail'); v.scrollTop = 0;
  v.innerHTML = `<div class="dhero sk"><button class="dback" data-act="back">${ICON.back}</button></div><div class="dbody"><div class="sk" style="height:26px;border-radius:8px;width:70%;margin-top:14px"></div></div>`;
  let d;
  try{
    d = await tmdb(`/${type}/${id}`, { append_to_response: 'videos,credits,recommendations,similar,watch/providers,release_dates,content_ratings', include_video_language: (S.lang === 'bn' ? 'bn,' : '') + 'en,null' });
  }catch(e){ v.innerHTML = `<div class="dhero"><button class="dback" data-act="back">${ICON.back}</button></div>` + (S.key ? errBox(`renderDetail('${type}',${+id})`) : '<div style="padding:0 20px">' + keyCardHTML() + '</div>'); return; }
  if(location.hash !== `#${type}-${id}`) return;
  let overview = d.overview;
  if(!overview && S.lang !== 'en'){ try{ overview = (await tmdb(`/${type}/${id}`, { language: 'en-US' })).overview; }catch(e){} }
  const vids = (d.videos?.results || []).filter(x => x.site === 'YouTube');
  const tr = vids.find(x => x.type === 'Trailer' && x.official) || vids.find(x => x.type === 'Trailer') || vids.find(x => x.type === 'Teaser') || vids[0];
  const title = ttl(d), year = yr(d);
  const runtime = type === 'movie' ? d.runtime : (d.episode_run_time || [])[0];
  const rt = runtime ? (runtime >= 60 ? `${num(Math.floor(runtime / 60))}h ${num(runtime % 60)}m` : `${num(runtime)}m`) : '';
  let cert = '';
  try{
    if(type === 'movie'){ const r = (d.release_dates?.results || []).find(x => x.iso_3166_1 === 'US') || (d.release_dates?.results || [])[0]; cert = (r?.release_dates || []).map(x => x.certification).find(Boolean) || ''; }
    else { const r = (d.content_ratings?.results || []).find(x => x.iso_3166_1 === 'US') || (d.content_ratings?.results || [])[0]; cert = r?.rating || ''; }
  }catch(e){}
  const director = type === 'movie' ? (d.credits?.crew || []).find(c => c.job === 'Director')?.name : (d.created_by || []).map(c => c.name).join(', ');
  const prov = d['watch/providers']?.results || {};
  const reg = ['BD','IN','US'].map(r => prov[r]).find(Boolean);
  const pRow = (arr, k) => arr && arr.length ? `<div class="prow"><em>${esc(k)}</em>${arr.slice(0, 8).map(p => `<img src="${img(p.logo_path, 'w92')}" alt="${esc(p.provider_name)}">`).join('')}</div>` : '';
  const provHtml = reg && (reg.flatrate || reg.rent || reg.buy || reg.free || reg.ads)
    ? pRow([...(reg.free || []), ...(reg.ads || []), ...(reg.flatrate || [])], 'Stream') + pRow(reg.rent, 'Rent') + pRow(reg.buy, 'Buy') + `<button class="more" data-ext="${esc(reg.link)}">JustWatch ↗</button>`
    : `<div class="cy" style="margin:0">${esc(t('noProv'))}</div>`;
  const cast = (d.credits?.cast || []).slice(0, 16);
  const recs = ((d.recommendations?.results || []).length ? d.recommendations.results : (d.similar?.results || [])).filter(m => m.poster_path);
  v._data = { type, id: d.id, title, poster_path: d.poster_path, vote_average: d.vote_average, date: d.release_date || d.first_air_date || '' };

  v.innerHTML = `
    <div class="dhero">${d.backdrop_path ? `<img src="${img(d.backdrop_path, 'w1280')}" alt="">` : ''}<button class="dback" data-act="back" aria-label="back">${ICON.back}</button>
      ${tr ? `<button class="bigplay" data-trailer="${esc(tr.key)}" aria-label="trailer"><svg viewBox="0 0 24 24" fill="#fff"><path d="M7 4.5v15l12-7.5z"/></svg></button>` : ''}</div>
    <div class="dbody"><h1>${esc(title)}</h1>
      <div class="dmeta"><span>${num(year)}</span>${cert ? `<span class="pill">${esc(cert)}</span>` : ''}${rt ? `<span>${rt}</span>` : ''}${type === 'tv' && d.number_of_seasons ? `<span>${num(d.number_of_seasons)} ${esc(t('seasons'))}</span>` : ''}<span class="st">★ ${(d.vote_average || 0).toFixed(1)}</span><span class="pill hd">HD</span></div>
      <div class="gen">${(d.genres || []).map(g => `<span>${esc(g.name)}</span>`).join('')}</div></div>
    <div id="freeSlot"></div>
    <div class="dbtns">
      <button class="gbtn" ${tr ? `data-trailer="${esc(tr.key)}"` : `data-toast="noTrailer"`}>${ICON.trailer}${esc(t('trailer'))}</button>
    </div>
    <div class="acts">
      <button class="act ${inList(type, d.id) ? 'on' : ''}" data-mylist="${type}-${d.id}">${inList(type, d.id) ? ICON.check : ICON.plus}<span>${esc(t('myList'))}</span></button>
      <button class="act" data-ext="https://www.themoviedb.org/${type}/${d.id}">${ICON.rate}<span>${esc(t('rate'))}</span></button>
      <button class="act" data-share="https://www.themoviedb.org/${type}/${d.id}" data-stitle="${esc(title)}">${ICON.share}<span>${esc(t('share'))}</span></button>
    </div>
    ${overview ? `<div class="blk"><h2 class="bn">${esc(t('story'))}</h2><p class="ov" id="ov">${esc(overview)}</p><button class="more" data-act="ov">${esc(t('showMore'))}</button>${director ? `<p class="cy" style="margin-top:8px">${type === 'movie' ? 'Director' : 'Created by'}: ${esc(director)}</p>` : ''}</div>` : ''}
    ${cast.length ? `<div class="blk"><h2>${esc(t('cast'))}</h2></div><div class="cast">${cast.map(c => `<div class="person"><div class="ph">${c.profile_path ? `<img loading="lazy" src="${img(c.profile_path, 'w185')}" alt="">` : ''}</div><p>${esc(c.name)}</p><small>${esc(c.character || '')}</small></div>`).join('')}</div>` : ''}
    ${type === 'tv' ? `<div class="blk" id="seasons"></div>` : ''}
    <div class="blk"><h2 class="bn">${esc(t('where'))}</h2>${provHtml}</div>
    ${recs.length ? `<div class="tabs"><button class="on">${esc(t('similar'))}</button></div><div class="grid">${recs.slice(0, 12).map(m => card(m, type)).join('')}</div>` : ''}`;

  if(type === 'movie' && year) findFree(title, d.original_title, +year);
  if(type === 'tv') renderSeasons(id, d);
}
async function findFree(title, orig, year){
  try{
    const clean = s => String(s || '').replace(/[():"\[\]]/g, ' ').trim();
    const d = await iaSearch(`title:("${clean(title)}") AND ${IA_MOVIES}`, 1, 8, '');
    let m = d.items.find(x => x.year && Math.abs(+x.year - year) <= 1);
    if(!m && orig && orig !== title){ const d2 = await iaSearch(`title:("${clean(orig)}") AND ${IA_MOVIES}`, 1, 8, ''); m = d2.items.find(x => x.year && Math.abs(+x.year - year) <= 1); }
    const slot = $('#freeSlot'); if(!m || !slot) return;
    slot.innerHTML = `<button class="freecard" data-go="ia-${esc(m.identifier)}"><span class="ib" style="background:#10B981;color:#fff">${ICON.play}</span><span><b class="bn">${esc(t('freeCard'))}</b><small>${esc(t('freeCardSub'))}</small></span></button>`;
  }catch(e){}
}
function renderSeasons(id, d){
  const box = $('#seasons'); if(!box) return;
  const ss = (d.seasons || []).filter(s => s.season_number > 0 && s.episode_count > 0);
  if(!ss.length) return;
  box.innerHTML = `<h2>${esc(t('seasons'))}</h2><select class="sel" id="ssel">${ss.map(s => `<option value="${s.season_number}">${esc(s.name)} · ${num(s.episode_count)} ${esc(t('episodes'))}</option>`).join('')}</select><div id="eps"></div>`;
  const load = async n => {
    const eps = $('#eps'); eps.innerHTML = `<div class="sentinel"><div class="spin"></div></div>`;
    try{
      const s = await tmdb(`/tv/${id}/season/${n}`);
      eps.innerHTML = (s.episodes || []).map(e => `<div class="ep"><div class="st">${e.still_path ? `<img loading="lazy" src="${img(e.still_path, 'w300')}" alt="">` : ''}</div><div style="min-width:0"><h4>${num(e.episode_number)}. ${esc(e.name)}</h4><small>${e.runtime ? num(e.runtime) + 'm · ' : ''}${esc(num(e.air_date || ''))}</small>${e.overview ? `<p>${esc(e.overview)}</p>` : ''}</div></div>`).join('');
    }catch(err){ eps.innerHTML = `<div class="cy">${esc(t('error'))}</div>`; }
  };
  $('#ssel').onchange = e => load(e.target.value);
  load(ss[0].season_number);
}

/* ---------- Detail (Internet Archive, free) ---------- */
async function renderIA(id){
  const v = $('#v-detail'); v.scrollTop = 0;
  v.innerHTML = `<div class="dhero sk"><button class="dback" data-act="back">${ICON.back}</button></div><div class="dbody"><div class="sk" style="height:26px;border-radius:8px;width:70%;margin-top:14px"></div></div>`;
  let meta;
  try{ meta = await iaMeta(id); if(!meta || !meta.metadata) throw 0; }
  catch(e){ v.innerHTML = `<div class="dhero"><button class="dback" data-act="back">${ICON.back}</button></div>` + errBox(`renderIA('${esc(id)}')`); return; }
  if(location.hash !== '#ia-' + id) return;
  const md = meta.metadata, { eps, subs } = iaVideos(meta);
  const title = Array.isArray(md.title) ? md.title[0] : (md.title || id);
  const desc = stripHtml(Array.isArray(md.description) ? md.description.join('\n') : md.description);
  const year = md.year || (md.date || '').slice(0, 4);
  const poster = iaImg(id);
  v._data = { type: 'ia', id, title, poster, date: year };
  v._ia = { eps, subs, title, poster, id };
  const main = eps[0];
  v.innerHTML = `
    <div class="dhero"><img src="${poster}" alt="" style="object-fit:contain;background:#000"><button class="dback" data-act="back" aria-label="back">${ICON.back}</button>
      ${main ? `<button class="bigplay" data-iaplay="0" aria-label="play"><svg viewBox="0 0 24 24" fill="#fff"><path d="M7 4.5v15l12-7.5z"/></svg></button>` : ''}</div>
    <div class="dbody"><h1>${esc(title)}</h1>
      <div class="dmeta">${year ? `<span>${num(year)}</span>` : ''}${md.runtime ? `<span>${esc(md.runtime)}</span>` : ''}<span class="pill" style="background:#10B981;color:#fff;border:0">${t('free')}</span><span class="pill">Public Domain</span></div>
      ${md.creator ? `<div class="cy" style="margin:0">${esc([].concat(md.creator).join(', '))}</div>` : ''}</div>
    <div class="dbtns">
      ${main ? `<button class="gbtn" data-iaplay="0">${ICON.play}${esc(t('play'))}</button><button class="sbtn" data-iadl="0">${ICON.dl}${esc(t('download'))}</button>` : `<div class="cy">${esc(t('noRes'))}</div>`}
    </div>
    <div class="acts">
      <button class="act ${inList('ia', id) ? 'on' : ''}" data-mylist="ia-${esc(id)}">${inList('ia', id) ? ICON.check : ICON.plus}<span>${esc(t('myList'))}</span></button>
      <button class="act" data-ext="https://archive.org/details/${encodeURIComponent(id)}">${ICON.rate}<span>Archive</span></button>
      <button class="act" data-share="https://archive.org/details/${encodeURIComponent(id)}" data-stitle="${esc(title)}">${ICON.share}<span>${esc(t('share'))}</span></button>
    </div>
    ${desc ? `<div class="blk"><h2 class="bn">${esc(t('story'))}</h2><p class="ov" id="ov">${esc(desc)}</p><button class="more" data-act="ov">${esc(t('showMore'))}</button></div>` : ''}
    ${eps.length > 1 ? `<div class="blk"><h2>${esc(t('episodes'))} (${num(eps.length)})</h2>${eps.map((e, i) => `<button class="ep" data-iaplay="${i}"><div class="st"><img loading="lazy" src="${poster}" alt=""></div><div style="min-width:0"><h4>${num(i + 1)}. ${esc(e.title)}</h4><small>${esc(e.sources[0].label)} · ${fmtSize(e.sources[0].size)}</small></div></button>`).join('')}</div>` : ''}
    <div class="tabs"><button class="on">${esc(t('freeMovies'))}</button></div><div id="iamore"></div>`;
  infiniteGrid($('#iamore'), rowLoader({ src: 'ia', q: IA_MOVIES }));
}
function playIA(i){
  const x = $('#v-detail')._ia; if(!x) return;
  const e = x.eps[i]; if(!e) return;
  openPlayer({ key: 'ia:' + x.id + ':' + i, title: x.eps.length > 1 ? `${x.title} · ${e.title}` : x.title, poster: x.poster, sources: e.sources, subs: x.subs, route: '#ia-' + x.id });
}
function dlIA(i){
  const x = $('#v-detail')._ia; if(!x) return;
  const e = x.eps[i];
  sheet(`<h3>${esc(t('chooseQ'))}</h3>${e.sources.map((s, j) => `<button class="opt" data-dlq="${j}"><span>${esc(s.label)} <small style="color:var(--muted)">· ${esc(s.name.split('.').pop().toUpperCase())}</small></span><span>${fmtSize(s.size)} ${ICON.chev}</span></button>`).join('')}`);
  $('#sheet').onclick = ev => {
    const b = ev.target.closest('[data-dlq]'); if(!b) return;
    const s = e.sources[+b.dataset.dlq];
    const fname = (x.id + '_' + s.name.split('/').pop()).replace(/[^\w.\-]+/g, '_');
    closeSheet();
    if(A && A.download){
      const saved = A.download(s.url, fname, x.title);
      S.dls[saved || fname] = { title: e.title && x.eps.length > 1 ? `${x.title} · ${e.title}` : x.title, poster: x.poster, route: '#ia-' + x.id };
      store.set('dls', S.dls);
      toast(t('dlStarted'));
    } else { window.open(s.url, '_blank'); }
  };
}

/* ---------- My List ---------- */
const inList = (type, id) => S.list.some(x => x.type === type && String(x.id) === String(id));
async function toggleList(type, id){
  if(inList(type, id)){ S.list = S.list.filter(x => !(x.type === type && String(x.id) === String(id))); toast(t('removed')); }
  else {
    const dd = $('#v-detail')._data;
    let it = (dd && dd.type === type && String(dd.id) === String(id)) ? { ...dd } : null;
    if(!it){ for(const h of document.querySelectorAll('.hero')){ const m = (h._items || []).find(x => String(x.id) === String(id)); if(m){ it = { type, id: m.id, title: ttl(m), poster_path: m.poster_path, vote_average: m.vote_average, date: m.release_date || m.first_air_date || '' }; break; } } }
    if(!it && type !== 'ia'){ try{ const d = await tmdb(`/${type}/${id}`); it = { type, id: d.id, title: ttl(d), poster_path: d.poster_path, vote_average: d.vote_average, date: d.release_date || d.first_air_date || '' }; }catch(e){ return toast(t('error')); } }
    if(!it) return;
    S.list.unshift(it); toast(t('added'));
  }
  store.set('list', S.list);
  document.querySelectorAll(`[data-mylist="${CSS.escape(type + '-' + id)}"]`).forEach(b => {
    const on = inList(type, id); b.classList.toggle('on', on);
    const svg = b.querySelector('svg'); if(svg) svg.outerHTML = on ? ICON.check : ICON.plus;
  });
}
function listCard(m){
  if(m.type === 'ia') return iaCard({ identifier: m.id, title: m.title, year: m.date });
  return card({ id: m.id, title: m.title, poster_path: m.poster_path, vote_average: m.vote_average, release_date: m.date, media_type: m.type });
}

/* ---------- Profile ---------- */
function renderProfile(){
  const v = $('#v-profile');
  const watched = Object.values(S.hist).reduce((s, h) => s + Math.min(h.pos || 0, h.dur || 0), 0);
  let dlCount = 0; try{ dlCount = A && A.listDownloads ? JSON.parse(A.listDownloads()).length : 0; }catch(e){}
  const ver = A && A.getVersionName ? A.getVersionName() : 'web';
  const item = (act, bg, color, icon, label, val = '') => `<button class="item" data-act="${act}"><span class="ib" style="background:${bg};color:${color}">${icon}</span><span class="bn">${esc(label)}</span><span class="val">${val} ${ICON.chev}</span></button>`;
  v.innerHTML = `
    <div class="ptitle" style="justify-content:space-between">${esc(t('profile'))}<button class="cbtn" data-act="name" aria-label="${esc(t('editName'))}">${ICON.edit}</button></div>
    <div class="pcard"><div class="pav"><i>${esc((S.name || 'C')[0].toUpperCase())}</i><div><b>${esc(S.name)}</b><small>${APP_NAME} · v${esc(ver)}</small></div></div>
      <div class="stats"><div class="stat"><b>${num(S.list.length)}</b><span class="bn">${esc(t('myList'))}</span></div><div class="stat"><b>${num(dlCount)}</b><span class="bn">${esc(t('downloads'))}</span></div><div class="stat"><b>${num(Math.round(watched / 3600))}h</b><span class="bn">${esc(t('watched'))}</span></div></div></div>
    <div class="glabel bn">${esc(t('library'))}</div>
    <div class="grp">
      ${item('mylist', '#2A1B3D', '#E879F9', ICON.plus, t('myList'))}
      ${item('downloads', '#1E2A44', '#60A5FA', ICON.dl, t('downloads'))}
      ${item('history', '#1F3A2E', '#34D399', '<svg class="i" viewBox="0 0 24 24"><circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/></svg>', t('history'))}
      ${item('myvideos', '#3A2A16', '#FBBF24', '<svg class="i" viewBox="0 0 24 24"><rect x="4" y="3.5" width="16" height="17" rx="2.5"/><path d="M10 9.5v5l4-2.5z"/></svg>', t('myVideos'), esc(t('phoneFiles')))}
    </div>
    <div class="glabel bn">${esc(t('settings'))}</div>
    <div class="grp">
      ${item('lang', '#2A1B3D', '#E879F9', '<svg class="i" viewBox="0 0 24 24"><circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17M12 3.5c2.5 2.5 3.5 5.5 3.5 8.5s-1 6-3.5 8.5c-2.5-2.5-3.5-5.5-3.5-8.5s1-6 3.5-8.5z"/></svg>', t('language'), S.lang === 'bn' ? 'বাংলা' : 'English')}
      ${item('theme', '#23262D', '#E5E7EB', '<svg class="i" viewBox="0 0 24 24"><path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z"/></svg>', t('theme'), esc(t(S.theme)))}
      ${item('subsize', '#1E2A44', '#60A5FA', '<svg class="i" viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="3"/><path d="M7 14h4M13 14h4M7 10.5h10"/></svg>', t('subStyle'), S.subSize.toUpperCase())}
      ${item('key', '#3A1A26', '#FB7185', '<svg class="i" viewBox="0 0 24 24"><circle cx="8" cy="15" r="4"/><path d="m11 12 9-9M17 6l2 2M15 8l2 2"/></svg>', t('apiKey'), S.key ? '✓' : '—')}
      ${item('update', '#1F3A2E', '#34D399', '<svg class="i" viewBox="0 0 24 24"><path d="M20 12a8 8 0 1 1-2.3-5.6M20 4v4h-4"/></svg>', t('checkUpd'), 'v' + esc(ver))}
      ${item('about', '#23262D', '#E5E7EB', '<svg class="i" viewBox="0 0 24 24"><circle cx="12" cy="12" r="8.5"/><path d="M12 11v5.5M12 7.5v.5"/></svg>', t('about'))}
    </div>
    <div class="about">This product uses the TMDB API but is not endorsed or certified by TMDB. Free movies are public-domain titles from the Internet Archive.</div>`;
}
function renderDownloads(container){
  const draw = () => {
    if(!container.isConnected) return clearInterval(container._iv);
    let files = [];
    try{ files = A && A.listDownloads ? JSON.parse(A.listDownloads()) : []; }catch(e){}
    if(!files.length){ container.innerHTML = `<div class="empty">${esc(t('noDl'))}</div>`; return; }
    container.innerHTML = files.map(f => {
      const m = S.dls[f.name] || {};
      const pct = f.total > 0 ? Math.round(f.size / f.total * 100) : 100;
      const done = f.status === 'done';
      return `<div class="dl"><div class="th">${m.poster ? `<img src="${esc(m.poster)}" alt="">` : ''}</div>
        <div class="tx"><b>${esc(m.title || f.name)}</b><small>${done ? fmtSize(f.size) : (f.status === 'failed' ? 'Failed' : pct + '% · ' + fmtSize(f.size) + ' / ' + fmtSize(f.total))}</small>${done ? '' : `<div class="pb"><i style="width:${pct}%"></i></div>`}</div>
        ${done ? `<button class="cbtn" data-playdl="${esc(f.name)}" aria-label="play">${ICON.play}</button>` : ''}
        <button class="cbtn" data-deldl="${esc(f.name)}" aria-label="delete">${ICON.trash}</button></div>`;
    }).join('');
  };
  draw();
  clearInterval(container._iv); container._iv = setInterval(draw, 1500);
}
function renderHistory(container){
  const items = Object.values(S.hist).sort((a,b) => b.t - a.t);
  container.innerHTML = items.length ? items.map(h => `<div class="dl" ${h.src ? `data-resume="${esc(h.key)}"` : ''}><div class="th">${h.poster ? `<img src="${esc(h.poster)}" alt="">` : ''}</div><div class="tx"><b>${esc(h.title)}</b><small>${fmtT(h.pos)} / ${fmtT(h.dur)}</small><div class="pb"><i style="width:${h.dur ? Math.round(h.pos / h.dur * 100) : 0}%"></i></div></div></div>`).join('') : `<div class="empty">${esc(t('noHist'))}</div>`;
}

/* ---------- sheets / modal ---------- */
function sheet(html){ $('#sheet').innerHTML = '<div class="grab"></div>' + html; $('#scrim').classList.add('on'); $('#sheet').onclick = null; }
function closeSheet(){ $('#scrim').classList.remove('on'); }
$('#scrim').addEventListener('click', e => { if(e.target.id === 'scrim') closeSheet(); });
function askText(title, help, value, onSave, ph = ''){
  sheet(`<h3>${esc(title)}</h3>${help ? `<p class="bn">${esc(help)}</p>` : ''}<input id="askin" value="${esc(value)}" placeholder="${esc(ph)}" autocomplete="off"><div class="row2"><button class="sbtn" data-x="c">${esc(t('cancel'))}</button><button class="gbtn" data-x="s">${esc(t('save'))}</button></div>`);
  $('#sheet').onclick = e => { const b = e.target.closest('[data-x]'); if(!b) return; if(b.dataset.x === 's') onSave($('#askin').value.trim()); closeSheet(); };
}
function openTrailer(key){
  $('#tframe').innerHTML = `<iframe src="https://www.youtube-nocookie.com/embed/${encodeURIComponent(key)}?autoplay=1&rel=0&playsinline=1" allow="autoplay; encrypted-media; fullscreen; picture-in-picture" allowfullscreen></iframe>`;
  $('#tyt').onclick = () => openExt('https://www.youtube.com/watch?v=' + encodeURIComponent(key));
  $('#tmodal').classList.add('on');
}
function closeTrailer(){ $('#tmodal').classList.remove('on'); $('#tframe').innerHTML = ''; }
$('#tclose').onclick = closeTrailer;
function openExt(url){ if(A && A.openExternal) A.openExternal(url); else window.open(url, '_blank'); }
function share(url, title){ if(A && A.share) A.share(`${title}\n${url}`); else if(navigator.share) navigator.share({ title, url }).catch(() => {}); else navigator.clipboard?.writeText(url).then(() => toast('Link copied')); }

/* ===================== PLAYER ===================== */
const P = { item: null, qi: 0, subUrl: null, si: -1, speed: 1, aspect: 'contain', locked: false, hideT: 0, sleepT: 0, saveT: 0, sleepLabel: '', lastTap: 0 };
const pv = $('#pv'), pl = $('#player');
function openPlayer(item){
  P.item = item; P.qi = 0; P.si = -1; P.locked = false;
  pl.classList.remove('locked', 'showlock');
  $('#ptitle').textContent = item.title || '';
  pv.className = 'cs-' + S.subSize;
  [...pv.querySelectorAll('track')].forEach(x => x.remove());
  const h = S.hist[item.key];
  setSource(0, h && h.dur && h.pos / h.dur < 0.95 ? h.pos : (item.startAt || 0));
  pv.playbackRate = P.speed;
  pv.style.objectFit = P.aspect;
  pl.classList.add('on'); document.body.classList.add('playing');
  showUI();
  if(A && A.setPlaying) A.setPlaying(true);
  if(A && A.keepScreenOn) A.keepScreenOn(true);
}
function setSource(i, at){
  const s = P.item.sources[i]; if(!s) return;
  P.qi = i;
  const wasPaused = pv.paused && pv.src;
  pv.removeAttribute('crossorigin');
  if(/^https:\/\/appassets/.test(s.url) || s.url.startsWith('blob:')) pv.removeAttribute('crossorigin');
  pv.src = s.url;
  pv.addEventListener('loadedmetadata', function f(){ pv.removeEventListener('loadedmetadata', f); if(at) try{ pv.currentTime = at; }catch(e){} pv.playbackRate = P.speed; if(!wasPaused) pv.play().catch(() => {}); });
  pv.load();
}
function closePlayer(){
  saveProgress();
  pv.pause(); pv.removeAttribute('src'); pv.load();
  pl.classList.remove('on', 'pip'); document.body.classList.remove('playing');
  clearTimeout(P.sleepT); P.sleepLabel = '';
  $('#psw').classList.remove('on');
  if(A && A.setFullscreen) A.setFullscreen(false);
  else if(document.fullscreenElement) document.exitFullscreen().catch(() => {});
  if(A && A.setPlaying) A.setPlaying(false);
  if(A && A.keepScreenOn) A.keepScreenOn(false);
  P.full = false;
  renderContinue();
}
function saveProgress(){
  const it = P.item; if(!it || !it.key || !pv.duration || !isFinite(pv.duration)) return;
  if(it.noHistory) return;
  const s = it.sources[P.qi] || {};
  S.hist[it.key] = { key: it.key, title: it.title, poster: it.poster, route: it.route, pos: pv.currentTime, dur: pv.duration, t: Date.now(), src: it.persist === false ? null : s.url, label: s.label, subs: it.subs || [] };
  const keys = Object.keys(S.hist); if(keys.length > 80){ keys.sort((a,b) => S.hist[a].t - S.hist[b].t).slice(0, keys.length - 80).forEach(k => delete S.hist[k]); }
  store.set('hist', S.hist);
}
function resume(key){
  const h = S.hist[key]; if(!h || !h.src) return;
  openPlayer({ key: h.key, title: h.title, poster: h.poster, route: h.route, sources: [{ url: h.src, label: h.label || 'HD' }], subs: h.subs || [] });
}
function showUI(){
  if(P.locked){ pl.classList.add('showlock'); clearTimeout(P.hideT); P.hideT = setTimeout(() => pl.classList.remove('showlock'), 2500); return; }
  pl.classList.remove('hide'); clearTimeout(P.hideT);
  P.hideT = setTimeout(() => { if(!pv.paused && !$('#psw').classList.contains('on')) pl.classList.add('hide'); }, 3200);
}
function drawPP(){ $('#ppbtn').innerHTML = pv.paused ? ICON.playF : ICON.pause; }
function drawTime(){
  const d = pv.duration || 0, c = pv.currentTime || 0;
  $('#pcur').textContent = fmtT(c); $('#pdur').textContent = fmtT(d);
  if(!P.seeking){ const p = d ? c / d * 1000 : 0; $('#pseek').value = p; $('#pseek').style.setProperty('--p', p / 10 + '%'); }
}
pv.addEventListener('play', () => { drawPP(); showUI(); });
pv.addEventListener('pause', () => { drawPP(); pl.classList.remove('hide'); saveProgress(); });
pv.addEventListener('timeupdate', () => { drawTime(); if(Date.now() - P.saveT > 5000){ P.saveT = Date.now(); saveProgress(); } });
pv.addEventListener('loadedmetadata', drawTime);
pv.addEventListener('waiting', () => pl.classList.add('buf'));
['playing','canplay','pause','error'].forEach(ev => pv.addEventListener(ev, () => pl.classList.remove('buf')));
pv.addEventListener('ended', () => { saveProgress(); pl.classList.remove('hide'); });
pv.addEventListener('error', () => { if(pl.classList.contains('on') && P.item){ const n = P.qi + 1; if(P.item.sources[n]){ toast('↻ ' + P.item.sources[n].label); setSource(n, pv.currentTime); } else toast(t('error')); } });
const seek = $('#pseek');
seek.addEventListener('input', () => { P.seeking = true; seek.style.setProperty('--p', seek.value / 10 + '%'); $('#pcur').textContent = fmtT(seek.value / 1000 * (pv.duration || 0)); showUI(); });
seek.addEventListener('change', () => { if(pv.duration) pv.currentTime = seek.value / 1000 * pv.duration; P.seeking = false; });
function skip(s){ if(!pv.duration) return; pv.currentTime = Math.max(0, Math.min(pv.duration, pv.currentTime + s)); const h = s < 0 ? $('#shl') : $('#shr'); h.classList.add('on'); clearTimeout(h._t); h._t = setTimeout(() => h.classList.remove('on'), 600); }
pl.addEventListener('click', e => {
  const b = e.target.closest('[data-p]');
  if(b){ e.stopPropagation(); playerAction(b.dataset.p); showUI(); return; }
  if(e.target.closest('.sheet')) return;
  if(e.target.closest('#psw')){ $('#psw').classList.remove('on'); return; }
  const now = Date.now(), x = e.clientX / innerWidth;
  if(!P.locked && now - P.lastTap < 300 && (x < .35 || x > .65)){ skip(x < .5 ? -10 : 10); P.lastTap = 0; return; }
  P.lastTap = now;
  if(P.locked){ showUI(); return; }
  if(pl.classList.contains('hide')) showUI(); else { pl.classList.add('hide'); }
});
function playerAction(a){
  switch(a){
    case 'close': closePlayer(); break;
    case 'toggle': pv.paused ? pv.play().catch(() => {}) : pv.pause(); break;
    case 'back10': skip(-10); break;
    case 'fwd10': skip(10); break;
    case 'lock': P.locked = true; pl.classList.add('locked'); toast(t('locked')); showUI(); break;
    case 'unlock': P.locked = false; pl.classList.remove('locked', 'showlock'); showUI(); break;
    case 'aspect': { const order = ['contain','cover','fill']; P.aspect = order[(order.indexOf(P.aspect) + 1) % 3]; pv.style.objectFit = P.aspect; toast(t({ contain:'fit', cover:'fill', fill:'stretch' }[P.aspect])); break; }
    case 'full': toggleFull(); break;
    case 'pip':
      if(A && A.enterPip) A.enterPip();
      else if(document.pictureInPictureEnabled) pv.requestPictureInPicture().catch(() => {});
      break;
    case 'settings': playerSettings(); break;
  }
}
function toggleFull(){
  P.full = !P.full;
  if(A && A.setFullscreen) A.setFullscreen(P.full);
  else if(P.full) pl.requestFullscreen?.().catch(() => {}); else document.exitFullscreen?.().catch(() => {});
}
window.onPip = on => { pl.classList.toggle('pip', !!on); if(!on) showUI(); };
function psheet(html){ $('#psheet').innerHTML = '<div class="grab"></div>' + html; $('#psw').classList.add('on'); clearTimeout(P.hideT); pl.classList.remove('hide'); }
function playerSettings(){
  const it = P.item, s = it.sources[P.qi] || {};
  const subName = P.si === -1 ? t('off') : (P.si === 'file' ? 'File' : (it.subs[P.si]?.label || 'On'));
  psheet(`<h3>Player</h3>
    ${it.sources.length > 1 ? `<button class="opt" data-ps="q"><span>${esc(t('quality'))}</span><span>${esc(s.label || 'Auto')} ›</span></button>` : ''}
    <button class="opt" data-ps="speed"><span>${esc(t('speed'))}</span><span>${P.speed}x ›</span></button>
    <button class="opt" data-ps="subs"><span>${esc(t('subs'))}</span><span>${esc(subName)} ›</span></button>
    <button class="opt" data-ps="subsize"><span>${esc(t('subStyle'))}</span><span>${S.subSize.toUpperCase()} ›</span></button>
    <button class="opt" data-ps="sleep"><span>${esc(t('sleep'))}</span><span>${esc(P.sleepLabel || t('off'))} ›</span></button>
    <button class="opt" data-ps="aspect"><span>${esc(t('aspect'))}</span><span>${esc(t({ contain:'fit', cover:'fill', fill:'stretch' }[P.aspect]))} ›</span></button>
    <button class="gbtn" style="width:100%;margin-top:12px" data-ps="close">${esc(t('done'))}</button>`);
}
$('#psheet').addEventListener('click', e => {
  e.stopPropagation();
  const b = e.target.closest('[data-ps],[data-pv]'); if(!b) return;
  const it = P.item;
  if(b.dataset.ps){
    const k = b.dataset.ps;
    if(k === 'close') return $('#psw').classList.remove('on');
    if(k === 'q') return psheet(`<h3>${esc(t('quality'))}</h3>` + it.sources.map((s, i) => `<button class="opt ${i === P.qi ? 'on' : ''}" data-pv="q:${i}"><span>${esc(s.label)}</span><span>${s.size ? fmtSize(s.size) : ''} ${i === P.qi ? '✓' : ''}</span></button>`).join(''));
    if(k === 'speed') return psheet(`<h3>${esc(t('speed'))}</h3>` + [0.5, 0.75, 1, 1.25, 1.5, 1.75, 2].map(x => `<button class="opt ${x === P.speed ? 'on' : ''}" data-pv="speed:${x}"><span>${x}x</span><span>${x === P.speed ? '✓' : ''}</span></button>`).join(''));
    if(k === 'subs') return psheet(`<h3>${esc(t('subs'))}</h3><button class="opt ${P.si === -1 ? 'on' : ''}" data-pv="sub:-1"><span>${esc(t('off'))}</span><span>${P.si === -1 ? '✓' : ''}</span></button>` + (it.subs || []).map((s, i) => `<button class="opt ${P.si === i ? 'on' : ''}" data-pv="sub:${i}"><span>${esc(s.label)}</span><span>${P.si === i ? '✓' : ''}</span></button>`).join('') + `<button class="opt" data-pv="sub:file"><span class="bn">${esc(t('loadSub'))}</span><span>📄</span></button>`);
    if(k === 'subsize') return psheet(`<h3>${esc(t('subStyle'))}</h3>` + [['s','Small'],['m','Medium'],['l','Large']].map(([x, n]) => `<button class="opt ${S.subSize === x ? 'on' : ''}" data-pv="ss:${x}"><span>${n}</span><span>${S.subSize === x ? '✓' : ''}</span></button>`).join(''));
    if(k === 'sleep') return psheet(`<h3>${esc(t('sleep'))}</h3>` + [[0, t('off')], [15, '15 ' + t('min')], [30, '30 ' + t('min')], [45, '45 ' + t('min')], [60, '60 ' + t('min')], [-1, t('endOf')]].map(([m, n]) => `<button class="opt" data-pv="sleep:${m}"><span class="bn">${esc(n)}</span><span></span></button>`).join(''));
    if(k === 'aspect') return psheet(`<h3>${esc(t('aspect'))}</h3>` + [['contain','fit'],['cover','fill'],['fill','stretch']].map(([x, n]) => `<button class="opt ${P.aspect === x ? 'on' : ''}" data-pv="asp:${x}"><span>${esc(t(n))}</span><span>${P.aspect === x ? '✓' : ''}</span></button>`).join(''));
  }
  const [k, val] = b.dataset.pv.split(':');
  if(k === 'q'){ setSource(+val, pv.currentTime); }
  if(k === 'speed'){ P.speed = +val; pv.playbackRate = P.speed; }
  if(k === 'sub'){ if(val === 'file') return $('#subfile').click(); setSub(val === '-1' ? -1 : +val); }
  if(k === 'ss'){ S.subSize = val; store.set('subSize', val); pv.className = 'cs-' + val; }
  if(k === 'sleep'){ clearTimeout(P.sleepT); P.sleepLabel = ''; P.sleepEnd = false; const m = +val;
    if(m > 0){ P.sleepT = setTimeout(() => { pv.pause(); toast('😴'); P.sleepLabel = ''; }, m * 60000); P.sleepLabel = m + ' ' + t('min'); }
    if(m === -1){ P.sleepLabel = t('endOf'); } }
  if(k === 'asp'){ P.aspect = val; pv.style.objectFit = val; }
  playerSettings();
});
function srt2vtt(s){ return 'WEBVTT\n\n' + String(s).replace(/\r/g, '').replace(/^\d+\s*$/gm, '').replace(/(\d\d:\d\d:\d\d),(\d\d\d)/g, '$1.$2').trim(); }
async function setSub(i){
  [...pv.querySelectorAll('track')].forEach(x => x.remove());
  if(P.subUrl){ URL.revokeObjectURL(P.subUrl); P.subUrl = null; }
  P.si = i;
  if(i === -1) return;
  try{
    const s = P.item.subs[i];
    const txt = await getText(s.url);
    addTrack(s.kind === 'vtt' ? txt : srt2vtt(txt), s.label);
  }catch(e){ toast(t('error')); P.si = -1; }
}
function addTrack(vtt, label){
  P.subUrl = URL.createObjectURL(new Blob([vtt], { type: 'text/vtt' }));
  const tr = document.createElement('track');
  tr.kind = 'subtitles'; tr.label = label || 'Sub'; tr.srclang = 'xx'; tr.src = P.subUrl; tr.default = true;
  pv.appendChild(tr);
  setTimeout(() => { for(const tt of pv.textTracks) tt.mode = 'showing'; }, 50);
}
$('#subfile').addEventListener('change', e => {
  const f = e.target.files[0]; if(!f) return;
  const r = new FileReader();
  r.onload = () => { [...pv.querySelectorAll('track')].forEach(x => x.remove()); const txt = String(r.result); addTrack(/^WEBVTT/.test(txt) ? txt : srt2vtt(txt), f.name); P.si = 'file'; playerSettings(); };
  r.readAsText(f); e.target.value = '';
});
$('#vidfile').addEventListener('change', e => {
  const f = e.target.files[0]; if(!f) return;
  const url = URL.createObjectURL(f);
  openPlayer({ key: 'local:' + f.name + ':' + f.size, title: f.name.replace(/\.[^.]+$/, ''), sources: [{ url, label: 'Original' }], subs: [], persist: false });
  e.target.value = '';
});

/* ===================== UPDATE (GitHub Releases) ===================== */
function cmpVer(a, b){ const x = String(a).split('.').map(n => parseInt(n) || 0), y = String(b).split('.').map(n => parseInt(n) || 0); for(let i = 0; i < 3; i++){ if((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) - (y[i] || 0); } return 0; }
async function checkUpdate(manual){
  if(!CFG.repo){ if(manual) toast('repo not set'); return; }
  try{
    const r = await getJSON(`https://api.github.com/repos/${CFG.repo}/releases/latest`, { Accept: 'application/vnd.github+json' });
    const latest = String(r.tag_name || '').replace(/^v/i, '');
    const cur = A && A.getVersionName ? A.getVersionName() : '0';
    const apk = (r.assets || []).find(a => /\.apk$/i.test(a.name));
    store.set('updChecked', Date.now());
    if(apk && cmpVer(latest, cur) > 0){
      sheet(`<h3 class="bn">🎉 ${esc(t('newUpd'))}</h3><p>v${esc(cur)} → <b style="color:var(--acc)">v${esc(latest)}</b> · ${fmtSize(apk.size)}</p>
        ${r.body ? `<p style="white-space:pre-line;margin-top:10px;font-size:13px">${esc(r.body).slice(0, 800)}</p>` : ''}
        <div id="updprog" style="display:none;margin-top:14px"><div class="pb" style="height:6px;border-radius:6px;background:var(--line);overflow:hidden"><i id="updbar" style="display:block;height:6px;width:0;background:var(--grad)"></i></div><p id="updtxt" class="bn" style="margin-top:8px">${esc(t('updating'))}</p></div>
        <div class="row2" id="updbtns"><button class="sbtn" data-u="later">${esc(t('later'))}</button><button class="gbtn" data-u="go">${esc(t('updNow'))}</button></div>`);
      $('#sheet').onclick = e => {
        const b = e.target.closest('[data-u]'); if(!b) return;
        if(b.dataset.u === 'later') return closeSheet();
        if(A && A.downloadUpdate){
          A.downloadUpdate(apk.browser_download_url);
          $('#updbtns').style.display = 'none'; $('#updprog').style.display = 'block';
          const iv = setInterval(() => {
            const p = A.updateProgress();
            if(p >= 0){ $('#updbar').style.width = p + '%'; $('#updtxt').textContent = t('updating') + ' ' + p + '%'; }
            if(p === 100){ clearInterval(iv); $('#updtxt').textContent = '✓ Install…'; setTimeout(closeSheet, 2500); }
            if(p === -2){ clearInterval(iv); $('#updtxt').textContent = t('error'); $('#updbtns').style.display = 'flex'; }
          }, 600);
        } else openExt(apk.browser_download_url);
      };
    } else if(manual) toast(t('latest') + ' (v' + cur + ')');
  }catch(e){ if(manual) toast(t('error')); }
}

/* ===================== THEME / LANG ===================== */
const mq = matchMedia('(prefers-color-scheme: light)');
function applyTheme(){
  const th = S.theme === 'auto' ? (mq.matches ? 'light' : 'dark') : S.theme;
  document.documentElement.dataset.theme = th;
  document.querySelector('meta[name=theme-color]').content = th === 'light' ? '#F6F5FA' : '#0E0F12';
  if(A && A.setBarColors) A.setBarColors(th === 'light');
}
mq.addEventListener?.('change', () => S.theme === 'auto' && applyTheme());
function applyLang(){ document.documentElement.lang = S.lang; document.querySelectorAll('[data-t]').forEach(el => el.textContent = t(el.dataset.t)); }
function resetViews(){ ['home','explore','kdrama','anime','list'].forEach(n => { const v = $('#v-' + n); v._built = false; v._done = false; }); cache.clear(); }

/* ===================== ROUTER ===================== */
const TABS = ['home','explore','kdrama','anime','profile'];
const SUBPAGES = { mylist: 'myList', downloads: 'downloads', history: 'history' };
function route(){
  const h = decodeURIComponent((location.hash || '#home').slice(1));
  const m = h.match(/^(movie|tv)-(\d+)$/), ia = h.match(/^ia-(.+)$/);
  let name = (m || ia) ? 'detail' : (TABS.includes(h) ? h : (h === 'list' || SUBPAGES[h]) ? 'list' : 'home');
  document.querySelectorAll('.view').forEach(v => v.classList.toggle('on', v.id === 'v-' + name));
  document.querySelectorAll('.nav button').forEach(b => b.classList.toggle('on', b.dataset.go === name));
  document.body.classList.toggle('detail', name === 'detail');
  const v = $('#v-' + name);
  if(m) renderDetail(m[1], m[2]);
  else if(ia) renderIA(ia[1]);
  else if(name === 'profile') renderProfile();
  else if(SUBPAGES[h]){
    S.listCfg = { title: t(SUBPAGES[h]), custom: h === 'mylist' ? c => { c.innerHTML = S.list.length ? `<div class="grid">${S.list.map(listCard).join('')}</div>` : `<div class="empty">${esc(t('emptyList'))}</div>`; } : h === 'downloads' ? renderDownloads : renderHistory };
    renderList();
  }
  else if(name === 'list') renderList();
  else if(name === 'explore') renderExplore();
  else if(!v._done){ v._done = true; ({ home: renderHome, kdrama: renderKdrama, anime: renderAnime })[name](); }
  else if(name === 'home') renderContinue();
}
window.addEventListener('hashchange', route);
let navDepth = 0;
window.addEventListener('hashchange', () => { navDepth++; });
/* Android back button */
window.cinedorBack = () => {
  if($('#psw').classList.contains('on')){ $('#psw').classList.remove('on'); return true; }
  if(pl.classList.contains('on')){ if(P.locked){ showUI(); return true; } closePlayer(); return true; }
  if($('#tmodal').classList.contains('on')){ closeTrailer(); return true; }
  if($('#scrim').classList.contains('on')){ closeSheet(); return true; }
  const h = (location.hash || '#home').slice(1);
  if(h && h !== 'home'){ if(navDepth > 0){ navDepth -= 2; history.back(); } else location.hash = 'home'; return true; }
  return false;
};
function goBack(){ if(!window.cinedorBack()) location.hash = 'home'; }

/* ===================== EVENTS ===================== */
document.addEventListener('click', e => {
  if(e.target.closest('#player')) return;
  const q = s => e.target.closest(s);
  let b;
  if((b = q('[data-trailer]'))){ e.stopPropagation(); return openTrailer(b.dataset.trailer); }
  if((b = q('[data-mylist]'))){ e.stopPropagation(); const v = b.dataset.mylist, i = v.indexOf('-'); return toggleList(v.slice(0, i), v.slice(i + 1)); }
  if((b = q('[data-iaplay]'))) return playIA(+b.dataset.iaplay);
  if((b = q('[data-iadl]'))) return dlIA(+b.dataset.iadl);
  if((b = q('[data-resume]'))) return resume(b.dataset.resume);
  if((b = q('[data-playdl]'))){ const n = b.dataset.playdl, m = S.dls[n] || {}; return openPlayer({ key: 'dl:' + n, title: m.title || n, poster: m.poster, route: '#downloads', sources: [{ url: location.origin + '/dl/' + encodeURIComponent(n), label: 'Offline' }], subs: [], persist: true }); }
  if((b = q('[data-deldl]'))){ if(A && A.deleteDownload){ A.deleteDownload(b.dataset.deldl); delete S.dls[b.dataset.deldl]; store.set('dls', S.dls); route(); } return; }
  if((b = q('[data-ext]'))) return openExt(b.dataset.ext);
  if((b = q('[data-share]'))) return share(b.dataset.share, b.dataset.stitle || APP_NAME);
  if((b = q('[data-toast]'))) return toast(t(b.dataset.toast));
  if((b = q('[data-row]'))){ const [p, i] = b.dataset.row.split(':'); return openList(ROWSETS[p][+i]); }
  if((b = q('[data-chip]'))){
    const c = b.dataset.chip;
    const map = { movies: { k:'popMovies', path:'/movie/popular', params:{}, type:'movie' }, series: { k:'popTv', path:'/tv/popular', params:{}, type:'tv' }, bn: { k:'bangla', path:'/discover/movie', params:{ with_original_language:'bn', sort_by:'popularity.desc' }, type:'movie' }, hi: { k:'hindi', path:'/discover/movie', params:{ with_original_language:'hi', sort_by:'popularity.desc' }, type:'movie' }, free: { k:'freeMovies', src:'ia', q: IA_MOVIES } };
    return openList(map[c]);
  }
  if((b = q('[data-lang-list]'))){ const c = b.dataset.langList; return openList({ title: b.textContent, path:'/discover/movie', params:{ with_original_language: c, sort_by:'popularity.desc' }, type:'movie' }); }
  if((b = q('[data-genre]'))) return openList({ title: b.dataset.gname, path:'/discover/movie', params:{ with_genres: b.dataset.genre, sort_by:'popularity.desc' }, type:'movie' });
  if((b = q('[data-recent]'))){ const inp = $('#sq'); inp.value = b.dataset.recent; return doSearch(inp.value); }
  if((b = q('[data-act]'))){
    const a = b.dataset.act;
    if(a === 'back') return goBack();
    if(a === 'ov'){ const o = $('#ov'); o.classList.toggle('open'); b.textContent = o.classList.contains('open') ? t('showLess') : t('showMore'); return; }
    if(a === 'mylist' || a === 'downloads' || a === 'history'){ location.hash = a; return; }
    if(a === 'myvideos') return $('#vidfile').click();
    if(a === 'lang'){ S.lang = S.lang === 'bn' ? 'en' : 'bn'; store.set('lang', S.lang); applyLang(); resetViews(); return renderProfile(); }
    if(a === 'theme'){ const o = ['dark','light','auto']; S.theme = o[(o.indexOf(S.theme) + 1) % 3]; store.set('theme', S.theme); applyTheme(); return renderProfile(); }
    if(a === 'subsize'){ const o = ['s','m','l']; S.subSize = o[(o.indexOf(S.subSize) + 1) % 3]; store.set('subSize', S.subSize); return renderProfile(); }
    if(a === 'key') return askText(t('apiKey'), t('keyHelp'), store.get('key', '') || '', v => { store.set('key', v); S.key = v || CFG.tmdbKey; resetViews(); toast(t('saved')); route(); }, 'TMDB v3 key / v4 token');
    if(a === 'name') return askText(t('editName'), '', S.name, v => { if(v){ S.name = v; store.set('name', v); renderProfile(); const hv = $('#v-home'); hv._done = false; } });
    if(a === 'update') return checkUpdate(true);
    if(a === 'about') return sheet(`<div style="display:flex;align-items:center;gap:12px;margin-bottom:10px"><span style="width:48px;height:48px">${LOGO}</span><h3 style="margin:0">${APP_NAME}</h3></div><p class="bn">${esc(t('version'))}: v${esc(A && A.getVersionName ? A.getVersionName() : 'web')}</p><p style="margin-top:8px">Movie data & images: TMDB (not endorsed or certified by TMDB). Free movies: public-domain titles from the Internet Archive.</p>`);
  }
  if((b = q('[data-go]'))){
    const g = b.dataset.go;
    if(location.hash === '#' + g){ const v = document.querySelector('.view.on'); v && v.scrollTo({ top: 0, behavior: 'smooth' }); }
    else location.hash = g;
  }
});

/* ===================== START ===================== */
applyTheme(); applyLang(); route();
if(Date.now() - store.get('updChecked', 0) > 6 * 3600 * 1000) setTimeout(() => checkUpdate(false), 2500);
