// GitHub Actions এই ফাইলটা বিল্ডের সময় নিজে লিখে দেয় (TMDB_API_KEY secret আর repo নাম দিয়ে)।
// লোকাল টেস্টের জন্য এখানে key বসাতে পারেন। অ্যাপের Profile → TMDB API Key থেকেও দেওয়া যায়।
window.CINEDOR_CONFIG = { tmdbKey: "", repo: "" };
